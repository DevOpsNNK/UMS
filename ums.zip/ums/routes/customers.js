// routes/customers.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all customers
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM CUSTOMERS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET customer by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT * FROM CUSTOMERS WHERE Customer_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Customer not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// post route for adding new customer
router.post('/', async (req, res) => {
    try {
        const { User_ID, Name, Email, Address_City, Customer_Type, Outstanding_Balance } = req.body;

        if (!User_ID || !Name || !Email || !Address_City || !Customer_Type || Outstanding_Balance === undefined) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // Check if User exists
        const userCheck = await pool.request()
            .input('User_ID', sql.VarChar(5), User_ID)
            .query('SELECT User_ID FROM USERS WHERE User_ID = @User_ID');

        if (userCheck.recordset.length === 0) {
            return res.status(400).json({ error: `User_ID ${User_ID} does not exist` });
        }

        // Check duplicate email
        const emailCheck = await pool.request()
            .input('Email', sql.VarChar(100), Email)
            .query('SELECT Email FROM CUSTOMERS WHERE Email = @Email');

        if (emailCheck.recordset.length > 0) {
            return res.status(400).json({ error: 'Email already exists' });
        }

        // Insert customer and get computed Customer_ID
        const result = await pool.request()
            .input('User_ID', sql.VarChar(5), User_ID)
            .input('Name', sql.VarChar(255), Name)
            .input('Email', sql.VarChar(100), Email)
            .input('Address_City', sql.VarChar(100), Address_City)
            .input('Customer_Type', sql.VarChar(50), Customer_Type)
            .input('Outstanding_Balance', sql.Decimal(10, 2), parseFloat(Outstanding_Balance))
            .query(`
                INSERT INTO CUSTOMERS
                (User_ID, Name, Email, Address_City, Customer_Type, Outstanding_Balance)
                OUTPUT INSERTED.Customer_ID
                VALUES (@User_ID, @Name, @Email, @Address_City, @Customer_Type, @Outstanding_Balance)
            `);

        const Customer_ID = result.recordset[0].Customer_ID;

        return res.status(201).json({
            message: 'Customer added successfully',
            Customer_ID
        });

    } catch (err) {
        console.error('ERROR:', err);
        return res.status(500).json({ error: err.message });
    }
});

// PUT update customer
router.put('/:id', async (req, res) => {
    try {
        const { Name, Email, Address_City, Customer_Type, Outstanding_Balance } = req.body;

        if (!Name || !Email || !Address_City || !Customer_Type || Outstanding_Balance === undefined) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        const request = pool.request();

        request
            .input('id', sql.VarChar(50), req.params.id)
            .input('Name', sql.VarChar(255), Name)
            .input('Email', sql.VarChar(100), Email)
            .input('Address_City', sql.VarChar(100), Address_City)
            .input('Customer_Type', sql.VarChar(50), Customer_Type)
            .input('Outstanding_Balance', sql.Decimal(10, 2), parseFloat(Outstanding_Balance));

        const result = await request.query(`
            UPDATE CUSTOMERS
            SET Name=@Name, Email=@Email, Address_City=@Address_City, 
                Customer_Type=@Customer_Type, Outstanding_Balance=@Outstanding_Balance
            WHERE Customer_ID=@id
        `);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }

        res.json({ message: 'Customer updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE customer
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM CUSTOMERS WHERE Customer_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }

        res.json({ message: 'Customer deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;

















































































/*---- IGNORE ----

// routes/customers.js
const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all customers
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM CUSTOMERS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET customer by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM CUSTOMERS WHERE Customer_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new customer
router.post('/', async (req, res) => {
    try {
        const { User_ID, Name, Email, Address_City, Customer_Type, Outstanding_Balance } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('User_ID', User_ID)
            .input('Name', Name)
            .input('Email', Email)
            .input('Address_City', Address_City)
            .input('Customer_Type', Customer_Type)
            .input('Outstanding_Balance', Outstanding_Balance)
            .query(`INSERT INTO CUSTOMERS (User_ID, Name, Email, Address_City, Customer_Type, Outstanding_Balance)
                    VALUES (@User_ID, @Name, @Email, @Address_City, @Customer_Type, @Outstanding_Balance)`);
        res.json({ message: 'Customer added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update customer
router.put('/:id', async (req, res) => {
    try {
        const { Name, Email, Address_City, Customer_Type, Outstanding_Balance } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Name', Name)
            .input('Email', Email)
            .input('Address_City', Address_City)
            .input('Customer_Type', Customer_Type)
            .input('Outstanding_Balance', Outstanding_Balance)
            .query(`UPDATE CUSTOMERS
                    SET Name=@Name, Email=@Email, Address_City=@Address_City, Customer_Type=@Customer_Type, Outstanding_Balance=@Outstanding_Balance
                    WHERE Customer_ID=@id`);
        res.json({ message: 'Customer updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE customer
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM CUSTOMERS WHERE Customer_ID=@id');
        res.json({ message: 'Customer deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;

*//*---- END IGNORE ----*/
