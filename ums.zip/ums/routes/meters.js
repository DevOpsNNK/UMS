// routes/meters.js
const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all meters
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM METERS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET meter by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query('SELECT * FROM METERS WHERE Meter_ID=@id');

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new meter
router.post('/', async (req, res) => {
    try {
        const { Connection_ID } = req.body;  // only Connection_ID is needed

        // Validate required fields
        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        // Insert Connection_ID only; Meter_ID is computed in the database
        const result = await pool.request()
            .input('Connection_ID', sql.VarChar(50), Connection_ID)
            .query(`
                INSERT INTO METERS (Connection_ID)
                OUTPUT inserted.Meter_ID
                VALUES (@Connection_ID)
            `);

        // Return the computed Meter_ID
        res.status(201).json({
            message: 'Meter added successfully',
            Meter_ID: result.recordset[0].Meter_ID
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update meter
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        // Check meter exists
        const check = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query(`SELECT Meter_ID FROM METERS WHERE Meter_ID=@id`);

        if (check.recordset.length === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        // Check Connection_ID exists
        const checkConn = await pool.request()
            .input('Connection_ID', sql.VarChar(50), Connection_ID)
            .query(`SELECT Connection_ID FROM CONNECTIONS WHERE Connection_ID=@Connection_ID`);

        if (checkConn.recordset.length === 0) {
            return res.status(400).json({ error: 'Connection_ID does not exist' });
        }

        await pool.request()
            .input('id', sql.VarChar(50), id)
            .input('Connection_ID', sql.VarChar(50), Connection_ID)
            .query(`
                UPDATE METERS 
                SET Connection_ID=@Connection_ID
                WHERE Meter_ID=@id
            `);

        res.json({ message: "Meter updated successfully" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE meter
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();

        const result = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query(`DELETE FROM METERS WHERE Meter_ID=@id`);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        res.json({ message: "Meter deleted successfully" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
































































/*---- IGNORE ----


// routes/meters.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// TEST SQL ROUTE (moved from server.js if needed here)
router.get('/test-users', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});

// GET all meters
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM METERS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET meter by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();
        const result = await pool.request()
            .input('id', id)
            .query('SELECT * FROM METERS WHERE Meter_ID=@id');

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


*/


// Use Number 4 for POST new meter


/*
// 1,POST new meter
router.post('/', async (req, res) => {
    try {
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Connection_ID', Connection_ID)
            .query('INSERT INTO METERS (Connection_ID) VALUES (@Connection_ID)');

        res.status(201).json({ message: 'Meter added successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 2.POST new meter
router.post('/', async (req, res) => {
    try {
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        // Get the last inserted Meter_ID
        const lastMeter = await pool.request()
            .query("SELECT TOP 1 Meter_ID FROM METERS ORDER BY Meter_ID DESC");

        let newMeterID = "MTR001";

        if (lastMeter.recordset.length > 0) {
            const lastID = lastMeter.recordset[0].Meter_ID; // ex: MTR009
            const number = parseInt(lastID.replace("MTR", "")) + 1;
            newMeterID = "MTR" + String(number).padStart(3, "0");
        }

        // Insert new meter
        await pool.request()
            .input('Meter_ID', newMeterID)
            .input('Connection_ID', Connection_ID)
            .query(`
                INSERT INTO METERS (Meter_ID, Connection_ID)
                VALUES (@Meter_ID, @Connection_ID)
            `);

        res.status(201).json({
            message: 'Meter added successfully',
            Meter_ID: newMeterID
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// 3.POST new meter (AUTO GENERATE ID)
router.post('/', async (req, res) => {
    try {
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        // Get last Meter_ID
        const result = await pool.request()
            .query("SELECT TOP 1 Meter_ID FROM METERS ORDER BY Meter_ID DESC");

        let newMeterID = "MTR001";

        if (result.recordset.length > 0) {
            const lastID = result.recordset[0].Meter_ID; // e.g., MTR009
            const number = parseInt(lastID.replace("MTR", "")) + 1;
            newMeterID = "MTR" + String(number).padStart(3, "0");
        }

        await pool.request()
            .input("Meter_ID", sql.VarChar(50), newMeterID)
            .input("Connection_ID", sql.VarChar(50), Connection_ID)
            .query(
                "INSERT INTO METERS (Meter_ID, Connection_ID) VALUES (@Meter_ID, @Connection_ID)"
            );

        res.status(201).json({
            message: "Meter added successfully",
            Meter_ID: newMeterID
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});


// 4. POST new meter (AUTO - SQL GENERATED ID)
router.post('/', async (req, res) => {
    try {
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        // INSERT only Connection_ID
        const insertResult = await pool.request()
            .input("Connection_ID", sql.VarChar(50), Connection_ID)
            .query(`
                INSERT INTO METERS (Connection_ID)
                OUTPUT INSERTED.Meter_Num
                VALUES (@Connection_ID)
            `);

        const meterNum = insertResult.recordset[0].Meter_Num;

        // Now compute Meter_ID manually (same logic SQL uses)
        const meterID = 'M' + meterNum.toString().padStart(3, '0');

        res.status(201).json({
            message: "Meter added successfully",
            Meter_ID: meterID
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});





/*
// PUT update meter
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { Connection_ID } = req.body;

        if (!Connection_ID) {
            return res.status(400).json({ error: 'Connection_ID is required' });
        }

        const pool = await getPool();

        const result = await pool.request()
            .input('id', id)
            .query('SELECT Meter_ID FROM METERS WHERE Meter_ID=@id');

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        await pool.request()
            .input('id', id)
            .input('Connection_ID', Connection_ID)
            .query('UPDATE METERS SET Connection_ID=@Connection_ID WHERE Meter_ID=@id');

        res.json({ message: 'Meter updated successfully' });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE meter
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();

        const result = await pool.request()
            .input('id', id)
            .query('DELETE FROM METERS WHERE Meter_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Meter not found' });
        }

        res.json({ message: 'Meter deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;


---- END IGNORE ----*/

















































