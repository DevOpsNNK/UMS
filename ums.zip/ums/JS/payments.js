// Auto-fill today as default payment date
document.getElementById('paymentDate').valueAsDate = new Date();

// Payment processing simulation
const processBtn = document.getElementById('processPaymentBtn');
const confirmation = document.getElementById('confirmationMessage');
const amountDue = document.getElementById('amountDue');
const outstandingBalance = document.getElementById('outstandingBalance');

processBtn.addEventListener('click', function() {
    const paidAmount = parseFloat(document.getElementById('paidAmount').value);
    const currentDue = parseFloat(amountDue.textContent.replace('$',''));

    if (paidAmount > currentDue) {
        alert("Paid amount cannot be greater than Amount Due.");
        return;
    }

    // Update UI values
    const newDue = (currentDue - paidAmount).toFixed(2);
    amountDue.textContent = `$${newDue}`;
    const newBalance = (parseFloat(outstandingBalance.textContent.replace('$','')) - paidAmount).toFixed(2);
    outstandingBalance.textContent = `$${newBalance}`;

    // Show confirmation
    confirmation.style.display = 'block';
    confirmation.textContent = `Payment of $${paidAmount.toFixed(2)} processed successfully!`;
});

// ====== Fetch calls (Backend port updated to 4000) ======

// Bills
// Get all bills
async function fetchBills() {
    const res = await fetch('http://localhost:3000/api/bills');  // port changed
    const bills = await res.json();
    console.log(bills);
}

// Add bill
async function addBill(bill) {
    const res = await fetch('http://localhost:3000/api/bills', { // port changed
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bill)
    });
    const data = await res.json();
    console.log(data);
}

// Example usage
// addBill({ Connection_ID: 1, Tariff_ID: 1, Total_Amount: 500, Amount_Due: 500, Status: 'Unpaid' });

// Payments
// Get all payments
async function fetchPayments() {
    const res = await fetch('http://localhost:3000/api/payments'); // port changed
    const payments = await res.json();
    console.log(payments);
}

// Add payment
async function addPayment(payment) {
    const res = await fetch('http://localhost:3000/api/payments', { // port changed
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payment)
    });
    const data = await res.json();
    console.log(data);
}

// Example usage
/*
addPayment({
    Bill_ID: 1,
    Amount_Paid: 200,
    Payment_Method: 'Cash',
    Cashier_ID: 3,
    Payment_Date: '2025-12-03'
});
*/

// ====== Login integration with backend ======
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert("Please fill all fields.");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', { // port changed
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (data.success) {
            // Redirect based on role returned from backend
            switch (data.role) {
                case 'Admin':
                    window.location.href = 'admin_dashboard.html';
                    break;
                case 'Manager':
                    window.location.href = 'manager_dashboard.html';
                    break;
                case 'Cashier':
                    window.location.href = 'cashier_dashboard.html';
                    break;
                case 'Meter_Reader':
                    window.location.href = 'meter_reader_dashboard.html';
                    break;
                case 'Customer':
                    window.location.href = 'customer_dashboard.html';
                    break;
                default:
                    alert("Invalid role returned from server!");
            }
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}

// Fetch all payments from backend
async function fetchPaymentsFromBackend() {
    try {
        const res = await fetch('http://localhost:3000/api/payments'); // port changed
        const payments = await res.json();
        console.log(payments);
    } catch(err) {
        console.error(err);
    }
}

// Add new payment to backend
async function addPaymentToBackend(payment) {
    try {
        const res = await fetch('http://localhost:3000/api/payments', { // port changed
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payment)
        });
        const data = await res.json();
        console.log(data);
    } catch(err) {
        console.error(err);
    }
}
