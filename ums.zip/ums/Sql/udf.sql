--------------------------------------------------
-- udf.sql - User Defined Functions for Utility Management System
--------------------------------------------------

USE DB_ums;
GO

----Calculate Monthly Bill
CREATE OR ALTER FUNCTION dbo.fn_CalculateMonthlyBill
(
    @CustomerID VARCHAR(50),
    @Year INT,
    @Month INT
)
RETURNS DECIMAL(12,2)
AS
BEGIN
    DECLARE @Total DECIMAL(12,2) = 0;
    DECLARE @MonthStart DATE = DATEFROMPARTS(@Year, @Month, 1);
    DECLARE @MonthEnd DATE = EOMONTH(@MonthStart);

    ;WITH ConnUnits AS (
        SELECT
            cn.Connection_ID,
            cn.Utility_Type,
            ISNULL(SUM(
                CASE 
                  WHEN r.Units_Consumed IS NOT NULL THEN r.Units_Consumed
                  ELSE (r.Current_Reading - COALESCE(r.Previous_Reading, 0))
                END
            ),0) AS Units
        FROM CONNECTIONS cn
        LEFT JOIN READINGS r ON r.Meter_ID IN (
            SELECT Meter_ID FROM METERS WHERE Connection_ID = cn.Connection_ID
        )
        AND r.Reading_Date BETWEEN @MonthStart AND @MonthEnd
        WHERE cn.Customer_ID = @CustomerID
        GROUP BY cn.Connection_ID, cn.Utility_Type
    ),
    ConnTariff AS (
        SELECT
            cu.Connection_ID,
            cu.Utility_Type,
            cu.Units,
            t.Unit_Rate,
            t.Fixed_Charge
        FROM ConnUnits cu
        OUTER APPLY (
            SELECT TOP (1) *
            FROM TARIFFS tf
            WHERE tf.Utility_Type = cu.Utility_Type
              AND tf.Effective_Date <= @MonthEnd
            ORDER BY tf.Effective_Date DESC
        ) t
    )
    SELECT @Total = ISNULL(SUM(Units * Unit_Rate + Fixed_Charge),0) FROM ConnTariff;

    RETURN ISNULL(@Total,0);
END;
GO

--  Calculate Late Payment Fee
CREATE OR ALTER FUNCTION dbo.fn_CalculateLateFee
(
    @AmountDue DECIMAL(12,2),
    @DaysLate INT
)
RETURNS DECIMAL(12,2)
AS
BEGIN
    DECLARE @RatePerDay DECIMAL(9,6) = 0.005;
    DECLARE @Fee DECIMAL(12,2) = ROUND(@AmountDue * @RatePerDay * @DaysLate, 2);
    RETURN CASE WHEN @Fee < 0 THEN 0 ELSE @Fee END;
END;