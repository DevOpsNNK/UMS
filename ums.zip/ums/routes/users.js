// routes/users.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all users
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM USERS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET user by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();

        // ISSUE: User_ID is INT in database, but VarChar(50) is used
        // FIX: Use sql.Int instead of sql.VarChar(50)
        const result = await pool.request()
            .input('id', sql.Int, id) // fixed
            .query('SELECT * FROM USERS WHERE User_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new user
router.post('/', async (req, res) => {
    try {
        const { Username, Password_Hash, Name, Role, Status } = req.body;

        if (!Username || !Password_Hash || !Name || !Role || !Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // ISSUE: User_ID is auto-incremented INT, no need to provide it (okay here), lengths in .input() should match DB
        await pool.request()
            .input('Username', sql.VarChar(100), Username) // DB is VARCHAR(100)
            .input('Password_Hash', sql.VarChar(255), Password_Hash)
            .input('Name', sql.VarChar(255), Name) // DB is VARCHAR(255)
            .input('Role', sql.VarChar(50), Role)
            .input('Status', sql.VarChar(20), Status)
            .query(`INSERT INTO USERS (Username, Password_Hash, Name, Role, Status)
                    VALUES (@Username, @Password_Hash, @Name, @Role, @Status)`);

        res.status(201).json({ message: 'User added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update user
router.put('/:id', async (req, res) => {
    try {
        const { Username, Password_Hash, Name, Role, Status } = req.body;

        if (!Username || !Password_Hash || !Name || !Role || !Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // ISSUE: ID type mismatch, DB uses INT
        const check = await pool.request()
            .input('id', sql.Int, req.params.id) // fixed
            .query('SELECT User_ID FROM USERS WHERE User_ID=@id');

        if (check.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        await pool.request()
            .input('id', sql.Int, req.params.id) // fixed
            .input('Username', sql.VarChar(100), Username)
            .input('Password_Hash', sql.VarChar(255), Password_Hash)
            .input('Name', sql.VarChar(255), Name)
            .input('Role', sql.VarChar(50), Role)
            .input('Status', sql.VarChar(20), Status)
            .query(`UPDATE USERS
                    SET Username=@Username, Password_Hash=@Password_Hash, Name=@Name, Role=@Role, Status=@Status
                    WHERE User_ID=@id`);

        res.json({ message: 'User updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE user
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();

        // ISSUE: ID type mismatch
        const result = await pool.request()
            .input('id', sql.Int, req.params.id) // fixed
            .query('DELETE FROM USERS WHERE User_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ message: 'User deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;















































































/*---- IGNORE ----


// routes/users.js
const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all users
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM USERS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET user by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM USERS WHERE User_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new user
router.post('/', async (req, res) => {
    try {
        const { Username, Password_Hash, Name, Role, Status } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Username', Username)
            .input('Password_Hash', Password_Hash)
            .input('Name', Name)
            .input('Role', Role)
            .input('Status', Status)
            .query(`INSERT INTO USERS (Username, Password_Hash, Name, Role, Status)
                    VALUES (@Username, @Password_Hash, @Name, @Role, @Status)`);
        res.json({ message: 'User added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update user
router.put('/:id', async (req, res) => {
    try {
        const { Username, Password_Hash, Name, Role, Status } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Username', Username)
            .input('Password_Hash', Password_Hash)
            .input('Name', Name)
            .input('Role', Role)
            .input('Status', Status)
            .query(`UPDATE USERS
                    SET Username=@Username, Password_Hash=@Password_Hash, Name=@Name, Role=@Role, Status=@Status
                    WHERE User_ID=@id`);
        res.json({ message: 'User updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE user
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM USERS WHERE User_ID=@id');
        res.json({ message: 'User deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;



*//*---- END IGNORE ----*/
