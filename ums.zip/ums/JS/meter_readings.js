/* =====================================================
   METER READINGS MODULE
   Matches:
   - METERS(Meter_ID)
   - READINGS table exactly
===================================================== */

/* =========================
   DOM ELEMENTS
   ========================= */
const meterSelect = document.getElementById('meterSelect');
const prevReadingInput = document.getElementById('prevReading');
const currentReadingInput = document.getElementById('currentReading');
const unitsConsumedInput = document.getElementById('unitsConsumed');
const readingDateInput = document.getElementById('readingDate');
const staffIdInput = document.getElementById('staffId');
const readingForm = document.querySelector('.reading-form');


/* =====================================================
   AUTO-FILL PREVIOUS READING
   Previous_Reading comes from last reading of meter
===================================================== */
meterSelect.addEventListener('change', () => {
    const selectedOption = meterSelect.selectedOptions[0];

    // data-prev simulates last stored reading from DB
    const previous = selectedOption?.dataset.prev;

    prevReadingInput.value = previous ? parseFloat(previous).toFixed(2) : '';
    unitsConsumedInput.value = '';
    currentReadingInput.value = '';
});


/* =====================================================
   CALCULATE UNITS CONSUMED
   Units_Consumed = Current_Reading - Previous_Reading
===================================================== */
currentReadingInput.addEventListener('input', () => {
    const prev = parseFloat(prevReadingInput.value);
    const current = parseFloat(currentReadingInput.value);

    if (!isNaN(prev) && !isNaN(current)) {
        unitsConsumedInput.value = (current - prev).toFixed(2);
    } else {
        unitsConsumedInput.value = '';
    }
});


/* =====================================================
   FORM SUBMISSION
   Inserts into READINGS table
===================================================== */
readingForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    const meterID = meterSelect.value;
    const previous = parseFloat(prevReadingInput.value);
    const current = parseFloat(currentReadingInput.value);
    const units = parseFloat(unitsConsumedInput.value);
    const readingDate = readingDateInput.value;
    const staffID = staffIdInput.value;

    /* =========================
       FRONTEND VALIDATION
       ========================= */

    if (!meterID) {
        alert('Please select a Meter ID.');
        return;
    }

    if (!readingDate) {
        alert('Please select a reading date.');
        return;
    }

    if (isNaN(current)) {
        alert('Please enter current reading.');
        return;
    }

    /* SQL CHECK constraint:
       Current_Reading >= Previous_Reading */
    if (current < previous) {
        alert('Current reading must be greater than or equal to previous reading!');
        return;
    }

    /* =========================
       DATA OBJECT → READINGS TABLE
       ========================= */
    const readingData = {
        Meter_ID: meterID,                 // FK → METERS.Meter_ID
        Reading_Date: readingDate,         // DATE
        Previous_Reading: previous,        // DECIMAL(10,2)
        Current_Reading: current,          // DECIMAL(10,2)
        Units_Consumed: units,              // DECIMAL(10,2)
        Reading_Staff_ID: staffID           // FK → USERS.User_ID
    };

    try {
        await addReading(readingData);
        alert(`Reading for Meter ${meterID} recorded successfully!`);

        readingForm.reset();
        prevReadingInput.value = '';
        unitsConsumedInput.value = '';

    } catch (err) {
        console.error(err);
        alert('Failed to record reading.');
    }
});


/* =====================================================
   FETCH API CALLS
===================================================== */

/* =========================
   METERS
   ========================= */

// Get all meters
async function fetchMeters() {
    const res = await fetch('http://localhost:3000/api/meters');
    const meters = await res.json();
    console.log("Meters:", meters);

    // (Optional future use)
    // Populate dropdown dynamically
}


// Add meter (uses Connection_ID only – SQL generates Meter_ID)
async function addMeter(meter) {
    const res = await fetch('http://localhost:3000/api/meters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(meter)
    });

    return await res.json();
}


/* =========================
   READINGS
   ========================= */

// Get all readings
async function fetchReadings() {
    const res = await fetch('http://localhost:3000/api/readings');
    const readings = await res.json();
    console.log("Readings:", readings);
}


// Add new reading (main usage)
async function addReading(reading) {
    const res = await fetch('http://localhost:3000/api/readings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reading)
    });

    if (!res.ok) {
        throw new Error('Failed to add reading');
    }

    return await res.json();
}


/* =====================================================
   LOGIN & AUTH (UNCHANGED LOGIC)
===================================================== */

// Verify logged-in user before allowing access
async function verifyLogin() {
    try {
        const res = await fetch('http://localhost:3000/api/auth/verify', {
            method: 'GET',
            credentials: 'include'
        });

        if (!res.ok) {
            window.location.href = "login.html";
        }

        const user = await res.json();
        console.log("Logged-in user:", user);

        // Auto-fill staff ID
        staffIdInput.value = user.User_ID;

    } catch (err) {
        console.error("Login verification failed:", err);
        window.location.href = "login.html";
    }
}

verifyLogin();
