// routes/payments.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all payments
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM PAYMENTS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET payment by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT * FROM PAYMENTS WHERE Payment_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Payment not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new payment
router.post('/', async (req, res) => {
    try {
        const { Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date } = req.body;

        // Validate required fields
        if (!Bill_ID || Amount_Paid === undefined || !Payment_Method || !Cashier_ID || !Payment_Date) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Bill_ID', sql.VarChar(50), Bill_ID)
            .input('Amount_Paid', sql.Decimal(10, 2), parseFloat(Amount_Paid))
            .input('Payment_Method', sql.VarChar(50), Payment_Method)
            .input('Cashier_ID', sql.VarChar(50), Cashier_ID)
            .input('Payment_Date', sql.DateTime, new Date(Payment_Date))
            .query(`INSERT INTO PAYMENTS (Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date)
                    VALUES (@Bill_ID, @Amount_Paid, @Payment_Method, @Cashier_ID, @Payment_Date)`);

        res.status(201).json({ message: 'Payment added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update payment
router.put('/:id', async (req, res) => {
    try {
        const { Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date } = req.body;

        if (!Bill_ID || Amount_Paid === undefined || !Payment_Method || !Cashier_ID || !Payment_Date) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .input('Bill_ID', sql.VarChar(50), Bill_ID)
            .input('Amount_Paid', sql.Decimal(10, 2), parseFloat(Amount_Paid))
            .input('Payment_Method', sql.VarChar(50), Payment_Method)
            .input('Cashier_ID', sql.VarChar(50), Cashier_ID)
            .input('Payment_Date', sql.DateTime, new Date(Payment_Date))
            .query(`UPDATE PAYMENTS
                    SET Bill_ID=@Bill_ID, Amount_Paid=@Amount_Paid, Payment_Method=@Payment_Method, Cashier_ID=@Cashier_ID, Payment_Date=@Payment_Date
                    WHERE Payment_ID=@id`);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Payment not found' });
        }

        res.json({ message: 'Payment updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE payment
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM PAYMENTS WHERE Payment_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Payment not found' });
        }

        res.json({ message: 'Payment deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;


















































































/*---- IGNORE ----


// routes/payments.js

const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all payments
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM PAYMENTS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET payment by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM PAYMENTS WHERE Payment_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new payment
router.post('/', async (req, res) => {
    try {
        const { Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Bill_ID', Bill_ID)
            .input('Amount_Paid', Amount_Paid)
            .input('Payment_Method', Payment_Method)
            .input('Cashier_ID', Cashier_ID)
            .input('Payment_Date', Payment_Date)
            .query(`INSERT INTO PAYMENTS (Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date)
                    VALUES (@Bill_ID, @Amount_Paid, @Payment_Method, @Cashier_ID, @Payment_Date)`);
        res.json({ message: 'Payment added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update payment
router.put('/:id', async (req, res) => {
    try {
        const { Bill_ID, Amount_Paid, Payment_Method, Cashier_ID, Payment_Date } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Bill_ID', Bill_ID)
            .input('Amount_Paid', Amount_Paid)
            .input('Payment_Method', Payment_Method)
            .input('Cashier_ID', Cashier_ID)
            .input('Payment_Date', Payment_Date)
            .query(`UPDATE PAYMENTS
                    SET Bill_ID=@Bill_ID, Amount_Paid=@Amount_Paid, Payment_Method=@Payment_Method, Cashier_ID=@Cashier_ID, Payment_Date=@Payment_Date
                    WHERE Payment_ID=@id`);
        res.json({ message: 'Payment updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE payment
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM PAYMENTS WHERE Payment_ID=@id');
        res.json({ message: 'Payment deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;

/*---- END IGNORE ----*/
