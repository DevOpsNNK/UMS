// routes/login.js

const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// POST /api/login
router.post('/', async (req, res) => {
    const { username, password } = req.body;

    try {
        const pool = await getPool();

        const result = await pool.request()
            .input('Username', sql.VarChar(20), username)
            .input('Password', sql.VarChar(10), password)
            .query(`
                SELECT User_ID, Role, Status
                FROM USERS
                WHERE Username = @Username
                  AND Password_Hash = @Password
            `);

        if (result.recordset.length === 0) {
            return res.json({ success: false });
        }

        const user = result.recordset[0];

        if (user.Status !== 'Active') {
            return res.json({ success: false, message: 'User not active' });
        }

        // optional login log
        await pool.request()
            .input('User_ID', sql.VarChar(5), user.User_ID)
            .query(`INSERT INTO LOGIN_LOGS (User_ID) VALUES (@User_ID)`);

        res.json({
            success: true,
            role: user.Role,
            userId: user.User_ID
        });

    } catch (err) {
        res.status(500).json({ success: false });
    }
});

module.exports = router;

















































/*const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// POST /api/login
router.post('/', async (req, res) => {
    const { username, password, role } = req.body;

    if (!username || !password || !role) {
        return res.status(400).json({ success: false, message: 'Missing fields' });
    }

    try {
        const pool = await getPool();

        const result = await pool.request()
            .input('username', sql.VarChar, username)
            .input('password', sql.VarChar, password)
            .input('role', sql.VarChar, role)
            .query(`
                SELECT UserID, Role
                FROM LoginUsers
                WHERE Username = @username
                  AND Password = @password
                  AND Role = @role
                  AND Status = 'Active'
            `);

        if (result.recordset.length === 0) {
            return res.json({ success: false });
        }

        res.json({
            success: true,
            role: result.recordset[0].Role
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false });
    }
});

module.exports = router;
*/