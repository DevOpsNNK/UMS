// routes/connections.js
const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// ===========================
// GET all connections
// ===========================
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM CONNECTIONS');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).json({ error: err.message });
    }
});

// ===========================
// GET connection by ID
// ===========================
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT * FROM CONNECTIONS WHERE Connection_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).json({ error: err.message });
    }
});

// ============================================
// POST ROUTE: Create new connection
// ============================================
// POST /connections
router.post('/', async (req, res) => {
    try {
        // Destructure required fields from request body
        let { Customer_ID, Utility_Type, Connection_Date, Status } = req.body;

        // Validate that all required fields are provided
        if (!Customer_ID || !Utility_Type || !Connection_Date || !Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // ✅ Step 1: Validate that Customer_ID exists in CUSTOMERS table
        const custCheck = await pool.request()
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .query(`SELECT 1 FROM CUSTOMERS WHERE Customer_ID = @Customer_ID`);

        if (custCheck.recordset.length === 0) {
            return res.status(400).json({ error: `Customer_ID ${Customer_ID} does not exist` });
        }

        // ✅ Step 2: Insert the new connection record
        const insertResult = await pool.request()
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            .input('Connection_Date', sql.Date, Connection_Date)
            .input('Status', sql.VarChar(20), Status)
            .query(`
                INSERT INTO CONNECTIONS (Customer_ID, Utility_Type, Connection_Date, Status)
                OUTPUT INSERTED.Connection_ID
                VALUES (@Customer_ID, @Utility_Type, @Connection_Date, @Status)
            `);

        // Get the generated Connection_ID from OUTPUT
        const newConnectionID = insertResult.recordset[0].Connection_ID;

        // Send 201 (Created) status with success message
        return res.status(201).json({
            message: "Connection added successfully",
            Connection_ID: newConnectionID
        });

    } catch (err) {
        console.error("ERROR:", err);
        return res.status(500).json({ error: err.message });
    }
});

// ===========================
// PUT update connection
// ===========================
// FIX: Removed duplicate PUTs and cleaned up
router.put('/:id', async (req, res) => {
    try {
        const { Customer_ID, Utility_Type, Connection_Status } = req.body;

        if (!Customer_ID || !Utility_Type || !Connection_Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // Check if connection exists
        const check = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT Connection_ID FROM CONNECTIONS WHERE Connection_ID=@id');

        if (check.recordset.length === 0) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        // Check if Customer exists to prevent FK error
        const checkCustomer = await pool.request()
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .query('SELECT Customer_ID FROM CUSTOMERS WHERE Customer_ID=@Customer_ID');

        if (checkCustomer.recordset.length === 0) {
            return res.status(400).json({ error: 'Customer_ID does not exist' });
        }

        // Update connection
        await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            .input('Connection_Status', sql.VarChar(20), Connection_Status)
            .query(`UPDATE CONNECTIONS
                    SET Customer_ID=@Customer_ID, Utility_Type=@Utility_Type, Connection_Status=@Connection_Status
                    WHERE Connection_ID=@id`);

        res.json({ message: 'Connection updated successfully' });

    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).json({ error: err.message });
    }
});

// ===========================
// DELETE connection
// ===========================
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();

        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM CONNECTIONS WHERE Connection_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        res.json({ message: 'Connection deleted successfully' });
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;








































































/*// routes/bills.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all connections
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM CONNECTIONS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET connection by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT * FROM CONNECTIONS WHERE Connection_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new connection
router.post('/', async (req, res) => {
    try {
        const { Customer_ID, Utility_Type, Connection_Status } = req.body;

        if (!Customer_ID || !Utility_Type || !Connection_Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            .input('Connection_Status', sql.VarChar(20), Connection_Status)
            .query(`INSERT INTO CONNECTIONS (Customer_ID, Utility_Type, Connection_Status)
                    VALUES (@Customer_ID, @Utility_Type, @Connection_Status)`);

        res.status(201).json({ message: 'Connection added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update connection
router.put('/:id', async (req, res) => {
    try {
        const { Customer_ID, Utility_Type, Connection_Status } = req.body;

        if (!Customer_ID || !Utility_Type || !Connection_Status) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            .input('Connection_Status', sql.VarChar(20), Connection_Status)
            .query(`UPDATE CONNECTIONS
                    SET Customer_ID=@Customer_ID, Utility_Type=@Utility_Type, Connection_Status=@Connection_Status
                    WHERE Connection_ID=@id`);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        res.json({ message: 'Connection updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE connection
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM CONNECTIONS WHERE Connection_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Connection not found' });
        }

        res.json({ message: 'Connection deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
*/






















































































/*---- IGNORE ----


// routes/connections.js

const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all connections
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM CONNECTIONS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET connection by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM CONNECTIONS WHERE Connection_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new connection
router.post('/', async (req, res) => {
    try {
        const { Customer_ID, Utility_Type, Connection_Status } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Customer_ID', Customer_ID)
            .input('Utility_Type', Utility_Type)
            .input('Connection_Status', Connection_Status)
            .query(`INSERT INTO CONNECTIONS (Customer_ID, Utility_Type, Connection_Status)
                    VALUES (@Customer_ID, @Utility_Type, @Connection_Status)`);
        res.json({ message: 'Connection added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update connection
router.put('/:id', async (req, res) => {
    try {
        const { Customer_ID, Utility_Type, Connection_Status } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Customer_ID', Customer_ID)
            .input('Utility_Type', Utility_Type)
            .input('Connection_Status', Connection_Status)
            .query(`UPDATE CONNECTIONS
                    SET Customer_ID=@Customer_ID, Utility_Type=@Utility_Type, Connection_Status=@Connection_Status
                    WHERE Connection_ID=@id`);
        res.json({ message: 'Connection updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE connection
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM CONNECTIONS WHERE Connection_ID=@id');
        res.json({ message: 'Connection deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;


---- END IGNORE ----*/
