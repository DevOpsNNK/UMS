----------------------------------
-- showdata.sql - Script to display all data from the UMS database tables
----------------------------------

use DB_ums;

SELECT * FROM Users;

SELECT * FROM CUSTOMERS;

SELECT * FROM TARIFFS;

SELECT * FROM [CONNECTIONS];

SELECT * FROM METERS;

SELECT * FROM READINGS;

SELECT * FROM BILLS;

SELECT * FROM  PAYMENTS;

SELECT * FROM COMPLAINTS;

