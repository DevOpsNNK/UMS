// JS/logout.js


 // * LOGOUT WITH BACKEND API
 // * Calls POST /api/logout
 
 async function logoutWithBackend() {
    const userId = localStorage.getItem('userId');

    try {
        await fetch('http://localhost:3000/api/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        });

    } catch (err) {
        console.error("Logout API failed", err);
    }

    // Clear frontend session
    localStorage.clear();

    // Redirect to login
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 2000);
}

// Auto logout when page loads
logoutWithBackend();
















































/*
// JS/logout.js


//This file runs ONLY when logout.html is loaded.
// Dashboards never call the API directly.

async function logoutWithBackend() {
    const userId = localStorage.getItem('userId');

    try {
        await fetch('http://localhost:3000/api/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        });
    } catch (err) {
        console.error("Logout API failed", err);
    }

    // Clear browser session
    localStorage.clear();

    // Redirect after showing logout page
    setTimeout(() => {
        window.location.href = '/login.html'; // ABSOLUTE PATH
    }, 2000);
}

// Auto-run
logoutWithBackend();

*/
















































/*// JS/logout.js


//  * LOGOUT WITH BACKEND API
// * Calls POST /api/logout
 
async function logoutWithBackend() {
    const userId = localStorage.getItem('userId');

    try {
        await fetch('http://localhost:3000/api/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        });
    } catch (err) {
        console.error("Logout API failed", err);
    }

    // Clear frontend session
    localStorage.clear();

    // ✅ ABSOLUTE PATH FIX
    setTimeout(() => {
        window.location.href = '/login.html';
    }, 2000);
}

// Auto logout when page loads
logoutWithBackend();
*/





















































/*// JS/logout.js
setTimeout(() => {
    window.location.href = "login.html";
}, 2000); // Redirect after 5 seconds

//fetch calls

// Fetch all users (for admin)
async function fetchUsers() {
    const res = await fetch('http://localhost:3000/api/users');
    const users = await res.json();
    console.log(users);
}

// Add new user
async function addUser(user) {
    const res = await fetch('http://localhost:3000/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    });
    const data = await res.json();
    console.log(data);
}

// Example usage
// addUser({ Username: 'john', Password_Hash: 'hashedpass', Name: 'John Doe', Role: 'Customer', Status: 'Active' });

// ====== NEW: Fully integrated login with backend ======
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert("Please fill all fields.");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (data.success) {
            // Redirect based on role returned from backend
            switch(data.role) {
                case 'Admin':
                    window.location.href = 'admin_dashboard.html';
                    break;
                case 'Manager':
                    window.location.href = 'manager_dashboard.html';
                    break;
                case 'Cashier':
                    window.location.href = 'cashier_dashboard.html';
                    break;
                case 'Meter_Reader':
                    window.location.href = 'meter_reader_dashboard.html';
                    break;
                case 'Customer':
                    window.location.href = 'customer_dashboard.html';
                    break;
                default:
                    alert("Invalid role!");
            }
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}

// Backend integration for users (optional: e.g., admin can fetch users on logout)
async function fetchUsersFromBackend() {
    try {
        const res = await fetch('http://localhost:3000/api/users');
        const users = await res.json();
        console.log(users);
    } catch (err) {
        console.error(err);
    }
}

// Optional: Add new user on logout (example, rarely used)
async function addUserToBackend(user) {
    try {
        const res = await fetch('http://localhost:3000/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user)
        });
        const data = await res.json();
        console.log(data);
    } catch (err) {
        console.error(err);
    }
}
*/