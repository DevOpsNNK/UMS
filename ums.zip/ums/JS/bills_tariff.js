//bills_tariff.js

// ==============================
// DOM Content Loaded
// ==============================
document.addEventListener('DOMContentLoaded', () => {

    // -----------------------------
    // Button: Calculate bills
    // -----------------------------
    document.querySelector('.calculate-btn').addEventListener('click', () => {
        alert('Billing calculation routine executed!');
        // Later you can call a backend function to calculate bills dynamically
    });

    // -----------------------------
    // Button: Manage tariffs
    // -----------------------------
    document.querySelector('.manage-btn').addEventListener('click', () => {
        alert('Redirecting to Tariff Management...');
        // Example: window.location.href = 'tariffs.html';
    });

    // -----------------------------
    // Search functionality
    // -----------------------------
    document.querySelector('.search-btn').addEventListener('click', () => {
        const searchInput = document.querySelector('.filter-controls input').value.toLowerCase();
        const filter = document.querySelector('.filter-controls select').value;
        const rows = document.querySelectorAll('.data-table tbody tr');

        rows.forEach(row => {
            const billID = row.children[0].textContent.toLowerCase(); // Bill_ID column
            const connID = row.children[1].textContent.toLowerCase(); // Connection_ID column
            const status = row.children[5].textContent.toLowerCase(); // Status column (index 5)

            // Check if row matches search text and filter
            let matchesSearch = billID.includes(searchInput) || connID.includes(searchInput);
            let matchesStatus = (filter === 'all') || (status === filter.toLowerCase());

            // Hide or show row based on search/filter
            row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
        });
    });
});

// ==============================
// Fetch & API calls (port 4000)
// ==============================

// Get all tariffs
async function fetchTariffs() {
    const res = await fetch('http://localhost:3000/api/tariffs');
    const tariffs = await res.json();
    console.log(tariffs); // Temporary: logs tariffs to console
}

// Add tariff
async function addTariff(tariff) {
    const res = await fetch('http://localhost:3000/api/tariffs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tariff)
    });
    const data = await res.json();
    console.log(data); // Temporary: logs new tariff response
}

// ==============================
// Login with backend
// ==============================
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert("Please fill all fields.");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (data.success) {
            // Redirect user based on role returned from backend
            switch (data.role) {
                case 'Admin':
                    window.location.href = 'admin_dashboard.html';
                    break;
                case 'Manager':
                    window.location.href = 'manager_dashboard.html';
                    break;
                case 'Cashier':
                    window.location.href = 'cashier_dashboard.html';
                    break;
                case 'Meter_Reader':
                    window.location.href = 'meter_reader_dashboard.html';
                    break;
                case 'Customer':
                    window.location.href = 'customer_dashboard.html';
                    break;
                default:
                    alert("Invalid role returned from server!");
            }
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}

// ==============================
// Bills API calls
// ==============================

// Fetch all bills
async function fetchBillsFromBackend() {
    try {
        const res = await fetch('http://localhost:3000/api/bills');
        const bills = await res.json();
        console.log(bills);
    } catch(err) {
        console.error(err);
    }
}

// Add new bill
async function addBillToBackend(bill) {
    try {
        const res = await fetch('http://localhost:3000/api/bills', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bill)
        });
        const data = await res.json();
        console.log(data);
    } catch(err) {
        console.error(err);
    }
}

// ==============================
// Tariffs API calls
// ==============================

// Fetch all tariffs
async function fetchTariffsFromBackend() {
    try {
        const res = await fetch('http://localhost:3000/api/tariffs');
        const tariffs = await res.json();
        console.log(tariffs);
    } catch(err) {
        console.error(err);
    }
}

// Add new tariff
async function addTariffToBackend(tariff) {
    try {
        const res = await fetch('http://localhost:3000/api/tariffs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tariff)
        });
        const data = await res.json();
        console.log(data);
    } catch(err) {
        console.error(err);
    }
}
