document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('.data-table tbody');

    // ===== LOG NEW COMPLAINT =====
    document.querySelector('.new-complaint-btn').addEventListener('click', () => {
        const newID = `CPL-${Math.floor(Math.random() * 9000 + 5000)}`;
        const newStaff = "STF-XXX"; // Placeholder for Staff_Assigned
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${newID}</td>                        <!-- Complaint_ID -->
            <td>CUST-XXXX</td>                        <!-- Customer_ID -->
            <td>New Complaint</td>                    <!-- Type -->
            <td>${newStaff}</td>                      <!-- Staff_Assigned -->
            <td class="status-open">Open</td>         <!-- Status -->
            <td><a href="#" class="view-link">View/Update</a></td> <!-- Actions -->
        `;
        tableBody.appendChild(row);
        alert('New complaint logged: ' + newID);
    });

    // ===== FILTER COMPLAINTS =====
    document.querySelector('.search-btn').addEventListener('click', () => {
        const statusFilter = document.querySelector('.filter-controls select').value.toLowerCase();
        const searchInput = document.querySelector('.filter-controls input').value.toLowerCase();
        const rows = tableBody.querySelectorAll('tr');

        rows.forEach(row => {
            const customerID = row.children[1].textContent.toLowerCase();  // Customer_ID
            const status = row.children[4].textContent.toLowerCase();      // Status
            const matchesSearch = customerID.includes(searchInput);
            const matchesStatus = statusFilter === 'open' || status === statusFilter;
            row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
        });
    });

    // ===== FETCH ALL COMPLAINTS =====
    async function fetchComplaints() {
        try {
            const res = await fetch('http://localhost:3000/api/complaints');
            const complaints = await res.json();

            // Clear existing table rows
            tableBody.innerHTML = '';

            // Populate table dynamically
            complaints.forEach(c => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${c.Complaint_ID}</td>
                    <td>${c.Customer_ID}</td>
                    <td>${c.Type}</td>
                    <td>${c.Staff_Assigned || ''}</td>
                    <td class="status-${c.Status.toLowerCase().replace(' ', '-')}">${c.Status}</td>
                    <td><a href="#" class="view-link">View/Update</a></td>
                `;
                tableBody.appendChild(row);
            });
        } catch (err) {
            console.error("Failed to fetch complaints:", err);
        }
    }

    fetchComplaints(); // Initial load
});

// ===== ADD COMPLAINT TO BACKEND =====
async function addComplaint(complaint) {
    try {
        const res = await fetch('http://localhost:3000/api/complaints', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(complaint)
        });
        const data = await res.json();
        console.log("Complaint added:", data);
        fetchComplaints(); // Refresh table
    } catch (err) {
        console.error("Failed to add complaint:", err);
    }
}

// ===== LOGIN & AUTH INTEGRATION =====
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!username || !password) return alert("Please fill all fields.");

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (data.success) {
            const roleRedirects = {
                'Admin': 'admin_dashboard.html',
                'Manager': 'manager_dashboard.html',
                'Cashier': 'cashier_dashboard.html',
                'Meter_Reader': 'meter_reader_dashboard.html',
                'Customer': 'customer_dashboard.html'
            };
            window.location.href = roleRedirects[data.role] || alert("Invalid role returned!");
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}

// ===== VERIFY LOGIN FOR SECURE PAGE =====
async function verifyLogin() {
    try {
        const res = await fetch('http://localhost:3000/api/auth/verify', { method: 'GET', credentials: 'include' });
        if (!res.ok) window.location.href = "login.html";

        const user = await res.json();
        console.log("Authenticated user:", user);
    } catch (err) {
        console.error("Login check failed:", err);
        window.location.href = "login.html";
    }
}

verifyLogin();
