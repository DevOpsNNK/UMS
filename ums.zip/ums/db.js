// db.js
require('dotenv').config();
const sql = require('mssql');

// Database configuration (SQL Authentication only)
const config = {
    server: process.env.DB_SERVER,           // localhost
    database: process.env.DB_DATABASE,       // ums
    port: parseInt(process.env.DB_PORT || '1433', 10),

    user: process.env.DB_USER,               // SA username from .env
    password: process.env.DB_PASSWORD,       // SA password from .env

    options: {
        encrypt: false,                      // false for local SQL Server
        trustServerCertificate: true
    },

    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    }
};

// Cached pool variable
let pool;

// Function to get a connected pool
async function getPool() {
    try {
        if (pool) return pool;

        pool = await sql.connect(config);
        console.log('✅ Database connected successfully');
        return pool;

    } catch (err) {
        console.error('🔥 Database Connection Error:', err);
        throw err;
    }
}

module.exports = { getPool, sql };



















/*// db.js
require('dotenv').config();
const sql = require('mssql');

// Database configuration using .env
const config = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    port: parseInt(process.env.DB_PORT || '1433', 10),
    options: {
        encrypt: true,              // true for Azure, false for local SQL Server
        trustServerCertificate: true // necessary for local dev
    },
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    }
};

// Cached pool variable to reuse connection
let pool;

// Function to get a connected pool
async function getPool() {
    try {
        if (pool) return pool; // reuse existing connection pool
        pool = await sql.connect(config);
        console.log('✅ Database connected');
        return pool;
    } catch (err) {
        console.error('🔥 Database Connection Error:', err);
        throw err;
    }
}

// Export getPool and sql
module.exports = { getPool, sql };
*/