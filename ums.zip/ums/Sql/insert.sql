------------------------------
--insert.sql a sql for inserting data into the tables created in create.sql
-- ----------------------------------------

USE DB_ums;
GO  

--go step by step inserting the data to avoid foreign key constraint errors


-- ===============================
-- step1 - Insert USERS
-- ===============================
INSERT INTO USERS (Username, Password_Hash, Name, Role, Status) VALUES
('admin02','hash1','Lakshitha Perera','Admin','Active'),
('manager01','hash2','Nimesha Silva','Manager','Active'),
('cashier01','hash3','Supun Jayasooriya','Cashier','Active'),
('cashier02','hash4','Harsha Fernando','Cashier','Active'),
('reader01','hash5','Isuru Kumara','Meter_Reader','Active'),
('reader02','hash6','Tharinda Gunasekara','Meter_Reader','Active'),
('cust01','hash7','Nadeesha Ranaweera','Customer','Active'),
('cust02','hash8','Dilani Wijesiri','Customer','Active'),
('cust03','hash9','Sahan Perera','Customer','Active'),
('cust04','hash10','Tharushi Menike','Customer','Active');


-- step 2 -Verify inserted USERS   
SELECT User_Num, User_ID, Username FROM USERS;
-- after running the above statement , note down the User_IDs generated for cust01, cust02, cust03, and cust04 to use in the CUSTOMERS insert below.


-- ===============================
-- step 3 -  Insert CUSTOMERS
-- ===============================
INSERT INTO CUSTOMERS (User_ID, Name, Email, Address_City, Customer_Type) VALUES
('U0001','Nadeesha Ranaweera','nadeesha@gmail.com','Colombo','Household'),
('U0002','Dilani Wijesiri','dilani@gmail.com','Kandy','Household'),
('U0003','Sahan Perera','sahanp@yahoo.com','Galle','Business'),
('U0004','Tharushi Menike','tharu@gmail.com','Matara','Household'),
('U0005','Nadun Kumara','nadun@gmail.com','Negombo','Government'),
('U0006','Ishara Weerasinghe','ishara@yahoo.com','Kurunegala','Business'),
('U0007','Kasun Thilakarathne','kasun@gmail.com','Jaffna','Household'),
('U0008','Nirmani Senanayake','nirmani@gmail.com','Anuradhapura','Household'),
('U0009','Pasan Madushanka','pasan@gmail.com','Rathnapura','Business'),
('U0010','Shenaya Dilhari','shenaya@gmail.com','Gampaha','Household');


-- ===============================
-- 3step 4 -  Insert TARIFFS
-- ===============================
INSERT INTO TARIFFS (Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date) VALUES
('Electricity', 55.50, 150.00, '2024-01-01'),
('Electricity', 68.20, 200.00, '2024-06-01'),
('Water', 12.75, 100.00, '2024-01-01'),
('Water', 14.50, 120.00, '2024-06-01'),
('Electricity', 50.00, 140.00, '2023-10-01'),
('Water', 10.00, 80.00, '2023-10-01'),
('Electricity', 72.00, 220.00, '2024-08-01'),
('Water', 16.00, 130.00, '2024-08-01'),
('Electricity', 65.00, 180.00, '2024-02-01'),
('Water', 11.50, 90.00, '2024-02-01');


-- step 5 - Verify inserted CUSTOMERS   
SELECT Customer_ID, User_ID, Name, Email FROM CUSTOMERS;
-- after running the above statement , note down the Customer_IDs generated to use in the CONNECTIONS insert below.


-- ===============================
-- step 6 -  Insert CONNECTIONS
-- ===============================
INSERT INTO CONNECTIONS (Customer_ID, Utility_Type, Status, Connection_Date) VALUES
('CUST0001','Electricity','Active','2025-12-29'),
('CUST0011','Water','Active','2025-12-29'),
('CUST0003','Electricity','Active','2025-12-29'),
('CUST0004','Water','Active','2025-12-29'),
('CUST0005','Electricity','Active','2025-12-29'),
('CUST0006','Water','Active','2025-12-29'),
('CUST0007','Electricity','Active','2025-12-29'),
('CUST0008','Water','Active','2025-12-29'),
('CUST0009','Electricity','Active','2025-12-29'),
('CUST0010','Water','Active','2025-12-29');


-- step 7 - Verify inserted CONNECTIONS 
SELECT Connection_ID, Customer_ID, Utility_Type, Status, Connection_Date FROM CONNECTIONS;
-- after running the above statement , note down the Connection_IDs generated to use in the METERS insert below.


-- ===============================
-- step 8 - Insert METERS
-- ===============================
INSERT INTO METERS (Connection_ID) VALUES
('CON0005'),
('CON0006'),
('CON0007'),
('CON0008'),
('CON0009'),
('CON0010'),
('CON0011'),
('CON0012'),
('CON0013'),
('CON0014');


-- step 9 - Verify inserted METERS yes
SELECT Meter_Num, Meter_ID, Connection_ID FROM METERS;
-- after running the above statement , note down the Meter_IDs generated to use in the READINGS insert below.


-- ===============================
-- step 10 - Insert READINGS
-- ===============================
INSERT INTO READINGS (Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Reading_Staff_ID) VALUES
('M0001','2024-01-01',0,120,'U0010'),
('M0004','2024-01-01',0,85,'U0001'),
('M0005','2024-01-01',0,150,'U0002'),
('M0006','2024-01-01',0,40,'U0003'),
('M0007','2024-01-01',0,200,'U0004'),
('M0008','2024-01-01',0,60,'U0005'),
('M0009','2024-01-01',0,140,'U0006'),
('M0010','2024-01-01',0,55,'U0007'),
('M0011','2024-01-01',0,165,'U0008'),
('M0012','2024-01-01',0,70,'U0009');


-- step 11 - Verify inserted CONNECTIONS and TARIFFS 
SELECT Connection_ID, Customer_ID, Utility_Type, Status, Connection_Date FROM CONNECTIONS;
SELECT Tariff_ID, Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date FROM TARIFFS;
-- after running the above statements , note down the Connection_IDs and Tariff_IDs generated to use in the BILLS insert below.


--===============================
-- step 12 -  Insert BILLS
-- ===============================
INSERT INTO BILLS (Connection_ID, Tariff_ID, Total_Amount, Amount_Due, Status) VALUES
('CON0005','T0001',800.00,800.00,'Unpaid'),
('CON0006','T0002',250.00,250.00,'Unpaid'),
('CON0007','T0003',950.00,950.00,'Unpaid'),
('CON0008','T0004',300.00,300.00,'Unpaid'),
('CON0009','T0005',700.00,700.00,'Unpaid'),
('CON0010','T0006',180.00,180.00,'Unpaid'),
('CON0011','T0007',1200.00,1200.00,'Unpaid'),
('CON0012','T0008',260.00,260.00,'Unpaid'),
('CON0013','T0009',900.00,900.00,'Unpaid'),
('CON0014','T0010',220.00,220.00,'Unpaid');


-- step 13 - Verify inserted BILLS 
SELECT Bill_ID, Connection_ID, Tariff_ID, Total_Amount, Amount_Due, Status FROM BILLS;
-- after running the above statement , note down the Bill_IDs generated to use in the PAYMENTS insert below.


-- ===============================
-- step 14 -  Insert PAYMENTS
-- ===============================
INSERT INTO PAYMENTS (Bill_ID, Amount_Paid, Payment_Method, Cashier_ID) VALUES
('B0012',400,'Cash','U0001'),
('B0013',250,'Online','U0002'),
('B0014',300,'Card','U0003'),
('B0015',100,'Cash','U0004'),
('B0016',200,'Online','U0005'),
('B0017',180,'Cash','U0006'),
('B0018',500,'Card','U0007'),
('B0019',260,'Cash','U0008'),
('B0020',300,'Online','U0009'),
('B0021',220,'Cash','U0010');


-- step 15 - Verify inserted CUSTOMERS    
SELECT Customer_ID, User_ID, Name, Email FROM CUSTOMERS;
-- after running the above statement , note down the Customer_IDs generated to use in the COMPLAINTS insert below.



-- ===============================
-- step 16 -  Insert COMPLAINTS
-- ===============================
INSERT INTO COMPLAINTS (Customer_ID, Type, Status, Staff_Assigned) VALUES
('CUST0001','High Bill','Open','U0001'),
('CUST0003','Meter Issue','In Progress','U0002'),
('CUST0004','Water Leakage','Open','U0003'),
('CUST0005','Connection Delay','Closed','U0004'),
('CUST0006','Reading Error','Open','U0005'),
('CUST0007','Wrong Tariff','In Progress','U0006'),
('CUST0008','No Water Supply','Open','U0007'),
('CUST0009','Billing Mistake','Closed','U0008'),
('CUST0010','Slow Service','Open','U0009'),
('CUST0011','Overcharging','In Progress','U0010');
