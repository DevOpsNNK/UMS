//Test  connection
//Create a file called testdb.js:

const { getPool } = require('./db');

(async () => {
  try {
    await getPool();
    console.log("🔥 TEST SUCCESS: SQL Connected");
  } catch (err) {
    console.error("❌ TEST FAILED:", err.message);
  }
})();


//Run:
//node testdb.js
//You should see:
//✅ Database connected successfully
//🔥 TEST SUCCESS: SQL Connected