--This will list every existing database on the server.
SELECT name 
FROM sys.databases;


DROP DATABASE DB_ums;

GO


USE DB_ums;
-- Quick sanity check (optional but recommended)
--Run this before testing login:

SELECT Username, Password_Hash, Role, Status FROM USERS;

--Database check
SELECT * FROM LOGIN_LOGS;
SELECT * FROM LOGOUT_LOGS;

