document.addEventListener('DOMContentLoaded', () => {

    /* =========================
       TAB SWITCHING
       ========================= */
    const tabs = document.querySelectorAll('.tab-button');
    const contentDiv = document.querySelector('.tab-content');

    const tabContents = [
        "All active services linked to this customer.",
        "Billing history will appear here.",
        "Customer complaints will appear here."
    ];

    tabs.forEach((tab, index) => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            contentDiv.innerHTML = `<p>${tabContents[index]}</p>`;

            if (index === 0) loadConnectionsTable();
            if (index === 1) loadBillingTable();
            if (index === 2) loadComplaintsTable();
        });
    });

    /* =========================
       CUSTOMER LIST CLICK
       ========================= */
    document.querySelectorAll('.customer-list-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.customer-list-item')
                .forEach(i => i.classList.remove('active'));

            item.classList.add('active');

            document.querySelector('.profile-summary h2').textContent =
                item.querySelector('strong').textContent;
        });
    });
});

/* =========================
   TABLE LOADERS
   ========================= */
function loadConnectionsTable() {
    document.querySelector('.tab-content').innerHTML += `
        <table class="data-table">
            <thead>
                <tr>
                    <th>Connection ID</th>
                    <th>Utility Type</th>
                    <th>Connection Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CONN001</td>
                    <td>Electricity</td>
                    <td>2023-06-12</td>
                    <td>Active</td>
                </tr>
            </tbody>
        </table>`;
}

function loadBillingTable() {
    document.querySelector('.tab-content').innerHTML += `
        <table class="data-table">
            <thead>
                <tr>
                    <th>Bill ID</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>B1001</td>
                    <td>2025-10-01</td>
                    <td>2500.00</td>
                    <td>Unpaid</td>
                </tr>
            </tbody>
        </table>`;
}

function loadComplaintsTable() {
    document.querySelector('.tab-content').innerHTML += `
        <table class="data-table">
            <thead>
                <tr>
                    <th>Complaint ID</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CPL5001</td>
                    <td>Billing Error</td>
                    <td>2025-11-28</td>
                    <td>Open</td>
                </tr>
            </tbody>
        </table>`;
}

/* =========================
   BACKEND API CALLS
   ========================= */

// GET all customers
async function fetchCustomers() {
    try {
        const res = await fetch('http://localhost:3000/api/customers');
        const customers = await res.json();
        console.log(customers);
    } catch (err) {
        console.error('Fetch customers error:', err);
    }
}

// ADD customer (NO Customer_ID sent)
async function addCustomer(customer) {
    /*
      customer = {
        User_ID: "U001",
        Name: "John Doe",
        Email: "john@email.com",
        Address_City: "Colombo",
        Customer_Type: "Household",
        Outstanding_Balance: 0
      }
    */

    try {
        const res = await fetch('http://localhost:3000/api/customers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(customer)
        });

        const data = await res.json();
        console.log('Customer added:', data);
    } catch (err) {
        console.error('Add customer error:', err);
    }
}

// GET connections
async function fetchConnections() {
    try {
        const res = await fetch('http://localhost:3000/api/connections');
        const connections = await res.json();
        console.log(connections);
    } catch (err) {
        console.error('Fetch connections error:', err);
    }
}

// ADD connection (Customer_ID is STRING like CUST0001)
async function addConnection(connection) {
    /*
      connection = {
        Customer_ID: "CUST0001",
        Utility_Type: "Water",
        Connection_Status: "Active"
      }
    */

    try {
        const res = await fetch('http://localhost:3000/api/connections', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(connection)
        });

        const data = await res.json();
        console.log('Connection added:', data);
    } catch (err) {
        console.error('Add connection error:', err);
    }
}
