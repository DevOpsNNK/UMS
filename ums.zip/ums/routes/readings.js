// routes/readings.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all readings
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM READINGS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET reading by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query('SELECT * FROM READINGS WHERE Reading_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Reading not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new reading
router.post('/', async (req, res) => {
    try {
        const { Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID } = req.body;

        // Validate required fields
        if (!Meter_ID || !Reading_Date || Previous_Reading === undefined || Current_Reading === undefined || Units_Consumed === undefined || !Reading_Staff_ID) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Meter_ID', sql.VarChar(50), Meter_ID)
            .input('Reading_Date', sql.DateTime, new Date(Reading_Date))
            .input('Previous_Reading', sql.Decimal(10, 2), parseFloat(Previous_Reading))
            .input('Current_Reading', sql.Decimal(10, 2), parseFloat(Current_Reading))
            .input('Units_Consumed', sql.Decimal(10, 2), parseFloat(Units_Consumed))
            .input('Reading_Staff_ID', sql.VarChar(50), Reading_Staff_ID)
            .query(`INSERT INTO READINGS (Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID)
                    VALUES (@Meter_ID, @Reading_Date, @Previous_Reading, @Current_Reading, @Units_Consumed, @Reading_Staff_ID)`);

        res.status(201).json({ message: 'Reading added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update reading
router.put('/:id', async (req, res) => {
    try {
        const { Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID } = req.body;

        if (!Meter_ID || !Reading_Date || Previous_Reading === undefined || Current_Reading === undefined || Units_Consumed === undefined || !Reading_Staff_ID) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        const check = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT Reading_ID FROM READINGS WHERE Reading_ID=@id');

        if (check.recordset.length === 0) {
            return res.status(404).json({ error: 'Reading not found' });
        }

        await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .input('Meter_ID', sql.VarChar(50), Meter_ID)
            .input('Reading_Date', sql.DateTime, new Date(Reading_Date))
            .input('Previous_Reading', sql.Decimal(10, 2), parseFloat(Previous_Reading))
            .input('Current_Reading', sql.Decimal(10, 2), parseFloat(Current_Reading))
            .input('Units_Consumed', sql.Decimal(10, 2), parseFloat(Units_Consumed))
            .input('Reading_Staff_ID', sql.VarChar(50), Reading_Staff_ID)
            .query(`UPDATE READINGS
                    SET Meter_ID=@Meter_ID, Reading_Date=@Reading_Date, Previous_Reading=@Previous_Reading, Current_Reading=@Current_Reading, Units_Consumed=@Units_Consumed, Reading_Staff_ID=@Reading_Staff_ID
                    WHERE Reading_ID=@id`);

        res.json({ message: 'Reading updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE reading
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM READINGS WHERE Reading_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Reading not found' });
        }

        res.json({ message: 'Reading deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;










































































/*---- IGNORE ----


// routes/readings.js

const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all readings
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM READINGS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET reading by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM READINGS WHERE Reading_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new reading
router.post('/', async (req, res) => {
    try {
        const { Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Meter_ID', Meter_ID)
            .input('Reading_Date', Reading_Date)
            .input('Previous_Reading', Previous_Reading)
            .input('Current_Reading', Current_Reading)
            .input('Units_Consumed', Units_Consumed)
            .input('Reading_Staff_ID', Reading_Staff_ID)
            .query(`INSERT INTO READINGS (Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID)
                    VALUES (@Meter_ID, @Reading_Date, @Previous_Reading, @Current_Reading, @Units_Consumed, @Reading_Staff_ID)`);
        res.json({ message: 'Reading added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update reading
router.put('/:id', async (req, res) => {
    try {
        const { Meter_ID, Reading_Date, Previous_Reading, Current_Reading, Units_Consumed, Reading_Staff_ID } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Meter_ID', Meter_ID)
            .input('Reading_Date', Reading_Date)
            .input('Previous_Reading', Previous_Reading)
            .input('Current_Reading', Current_Reading)
            .input('Units_Consumed', Units_Consumed)
            .input('Reading_Staff_ID', Reading_Staff_ID)
            .query(`UPDATE READINGS
                    SET Meter_ID=@Meter_ID, Reading_Date=@Reading_Date, Previous_Reading=@Previous_Reading, Current_Reading=@Current_Reading, Units_Consumed=@Units_Consumed, Reading_Staff_ID=@Reading_Staff_ID
                    WHERE Reading_ID=@id`);
        res.json({ message: 'Reading updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE reading
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM READINGS WHERE Reading_ID=@id');
        res.json({ message: 'Reading deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;


/*---- END IGNORE ----*/