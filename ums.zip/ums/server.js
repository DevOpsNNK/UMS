// server.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { getPool } = require('./db');   // IMPORTANT: import getPool

const app = express();
const PORT = process.env.PORT || 3000;

// =========================
// MIDDLEWARE (must be before routes)
// =========================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// =========================
// BASIC TEST ROUTE
// =========================
app.get("/api/test", (req, res) => {
    res.send("Server is running!");
});

// =========================
// API ROUTES
// =========================
app.use('/api/login', require('./routes/login'));
app.use('/api/logout', require('./routes/logout'));

app.use("/api/customers", require("./routes/customers"));
app.use("/api/users", require("./routes/users"));
app.use("/api/meters", require("./routes/meters"));
app.use("/api/readings", require("./routes/readings"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/bills", require("./routes/bills"));
app.use("/api/payments", require("./routes/payments"));
app.use("/api/connections", require("./routes/connections"));
app.use("/api/tariffs", require("./routes/tariffs"));

// =========================
// SQL TEST ROUTE
// =========================
app.get('/api/test-users', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});

// =========================
// FRONTEND ROUTES (HTML files)
// =========================

// Home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Catch-all frontend pages (must be LAST)
// Prevents API routes from being blocked
app.get('/:page', (req, res, next) => {
    if (req.params.page.startsWith("api")) {
        return res.status(404).json({ error: "API route not found" });
    }

    const filePath = path.join(__dirname, `${req.params.page}.html`);
    res.sendFile(filePath, (err) => {
        if (err) res.status(404).send("Page not found ❌");
    });
});

// =========================
// START SERVER
// =========================
app.listen(PORT, () => {
    console.log(`🚀 Backend running on port ${PORT}`);
});


































































/*// server.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { getPool } = require('./db');   // IMPORTANT

const app = express();
const PORT = process.env.PORT || 4000;

// =========================
// MIDDLEWARE (must be BEFORE routes)
// =========================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// =========================
// BASIC TEST ROUTE
// =========================
app.get("/api/test", (req, res) => {
    res.send("Server is running!");
});

// =========================
// API ROUTES
// =========================
app.use("/api/customers", require("./routes/customers"));
app.use("/api/users", require("./routes/users"));
app.use("/api/meters", require("./routes/meters"));
app.use("/api/readings", require("./routes/readings"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/bills", require("./routes/bills"));
app.use("/api/payments", require("./routes/payments"));
app.use("/api/connections", require("./routes/connections"));
app.use("/api/tariffs", require("./routes/tariffs"));

// =========================
// SQL TEST ROUTE
// =========================
app.get('/api/test-users', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});

// =========================
// FRONTEND ROUTES (HTML files)
// =========================

// Home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Prevent frontend pages from overriding /api/*
app.get('/:page', (req, res, next) => {
    if (req.params.page.startsWith("api")) {
        return res.status(404).json({ error: "API route not found" });
    }

    const filePath = path.join(__dirname, `${req.params.page}.html`);
    res.sendFile(filePath, (err) => {
        if (err) res.status(404).send("Page not found ❌");
    });
});

// =========================
// START SERVER
// =========================
app.listen(PORT, () => {
    console.log(`🚀 Backend running on port ${PORT}`);
});






/*
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { getPool } = require('./db');   // IMPORTANT FIX

const app = express();

// =========================
// MIDDLEWARE
// =========================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 4000;

// =========================
// API ROUTES
// =========================
app.use("/api/customers", require("./routes/customers"));
app.use("/api/users", require("./routes/users"));
app.use("/api/meters", require("./routes/meters"));
app.use("/api/readings", require("./routes/readings"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/bills", require("./routes/bills"));
app.use("/api/payments", require("./routes/payments"));
app.use("/api/connections", require("./routes/connections"));
app.use("/api/tariffs", require("./routes/tariffs"));

// =========================
// TEST SQL ROUTE
// =========================
app.get('/api/test-users', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});

// =========================
// FRONTEND ROUTES
// =========================
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/:page', (req, res) => {
    res.sendFile(path.join(__dirname, `${req.params.page}.html`), (err) => {
        if (err) res.status(404).send("Page not found ❌");
    });
});

// =========================
// START SERVER
// =========================
app.listen(PORT, () => {
    console.log(`🚀 Backend running on port ${PORT}`);
});






/* full
//server.js

require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const sql = require('mssql');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
app.get("/api/test", (req, res) => res.send("Server is running!"));



// DB config using .env variables
const config = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    port: parseInt(process.env.DB_PORT),
    options: {
        encrypt: true,               // use true if connecting to Azure
        trustServerCertificate: true // true for local dev
    }
};

// =========================
// ROUTES
// =========================
app.use("/api/customers", require("./routes/customers"));
app.use("/api/users", require("./routes/users"));
app.use("/api/meters", require("./routes/meters"));
app.use("/api/readings", require("./routes/readings"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/bills", require("./routes/bills"));
app.use("/api/payments", require("./routes/payments"));
app.use("/api/connections", require("./routes/connections"));
app.use("/api/tariffs", require("./routes/tariffs"));

// Middleware

//app.use(express.static(path.join(__dirname)));
app.use(express.static(path.join(__dirname, "public")));

app.use(cors());
app.use(express.json());


// =========================
// SAMPLE SQL ROUTE
// =========================
// SAMPLE SQL ROUTE


/*
//1.app.get('/api/test-users', async (req, res) => { 
//2.
app.get('/:page', (req, res, next) => {
    try {
        
        const pool = await sql.connect(config); // use 'config' not 'dbConfig'
        //const result = await pool.request().query('SELECT * FROM Users');  
        //res.json(result.recordset);
        // 
        //2.
        if (req.params.page.startsWith('api')) return next(); // allow API
        res.sendFile(path.join(__dirname, 'public', `${req.params.page}.html`));
        
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});*/


/*full
// =========================
// TEST SQL ROUTE
// =========================
app.get('/api/test-users', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        console.error("SQL ERROR:", err);
        res.status(500).send("Database query failed");
    }
});




// =========================
// FRONTEND ROUTES
// =========================
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/:page', (req, res) => {
    const filePath = path.join(__dirname, `${req.params.page}.html`);
    res.sendFile(filePath, err => {
        if (err) res.status(404).send("Page not found ❌");
    });
});

// Example backend check
app.get('/template', (req, res) => {
    res.send("Template route is working ✅");
});

// =========================
// START SERVER
// =========================
app.listen(PORT, () => {
    console.log(`🚀 Backend running on port ${PORT}`);
});
*/