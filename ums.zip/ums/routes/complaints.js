// routes/complaints.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all complaints
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM COMPLAINTS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET complaint by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('SELECT * FROM COMPLAINTS WHERE Complaint_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new complaint
router.post('/', async (req, res) => {
    try {
        const { Customer_ID, Type, Status, Staff_Assigned } = req.body;

        // Validate required fields
        if (!Customer_ID || !Type || !Status || !Staff_Assigned) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Type', sql.VarChar(50), Type)
            .input('Status', sql.VarChar(20), Status)
            .input('Staff_Assigned', sql.VarChar(50), Staff_Assigned)
            .query(`INSERT INTO COMPLAINTS (Customer_ID, Type, Status, Staff_Assigned)
                    VALUES (@Customer_ID, @Type, @Status, @Staff_Assigned)`);

        res.status(201).json({ message: 'Complaint added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update complaint
router.put('/:id', async (req, res) => {
    try {
        const { Customer_ID, Type, Status, Staff_Assigned } = req.body;

        // Validate required fields
        if (!Customer_ID || !Type || !Status || !Staff_Assigned) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .input('Customer_ID', sql.VarChar(50), Customer_ID)
            .input('Type', sql.VarChar(50), Type)
            .input('Status', sql.VarChar(20), Status)
            .input('Staff_Assigned', sql.VarChar(50), Staff_Assigned)
            .query(`UPDATE COMPLAINTS
                    SET Customer_ID=@Customer_ID, Type=@Type, Status=@Status, Staff_Assigned=@Staff_Assigned
                    WHERE Complaint_ID=@id`);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        res.json({ message: 'Complaint updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE complaint
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), req.params.id)
            .query('DELETE FROM COMPLAINTS WHERE Complaint_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Complaint not found' });
        }

        res.json({ message: 'Complaint deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;



















































































/* ---- IGNORE ----


// routes/complaints.js

const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all complaints
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM COMPLAINTS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET complaint by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM COMPLAINTS WHERE Complaint_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new complaint
router.post('/', async (req, res) => {
    try {
        const { Customer_ID, Type, Status, Staff_Assigned } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Customer_ID', Customer_ID)
            .input('Type', Type)
            .input('Status', Status)
            .input('Staff_Assigned', Staff_Assigned)
            .query(`INSERT INTO COMPLAINTS (Customer_ID, Type, Status, Staff_Assigned)
                    VALUES (@Customer_ID, @Type, @Status, @Staff_Assigned)`);
        res.json({ message: 'Complaint added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update complaint
router.put('/:id', async (req, res) => {
    try {
        const { Customer_ID, Type, Status, Staff_Assigned } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Customer_ID', Customer_ID)
            .input('Type', Type)
            .input('Status', Status)
            .input('Staff_Assigned', Staff_Assigned)
            .query(`UPDATE COMPLAINTS
                    SET Customer_ID=@Customer_ID, Type=@Type, Status=@Status, Staff_Assigned=@Staff_Assigned
                    WHERE Complaint_ID=@id`);
        res.json({ message: 'Complaint updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE complaint
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM COMPLAINTS WHERE Complaint_ID=@id');
        res.json({ message: 'Complaint deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;

*//*---- END IGNORE ----*/