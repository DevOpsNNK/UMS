// JS/login.js

document.querySelector('form').addEventListener('submit', loginWithBackend);

/**
 * LOGIN WITH BACKEND API
 * Calls POST /api/login
 */
async function loginWithBackend(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const roleSelect = document.getElementById('role').value;

    if (!username || !password || !roleSelect) {
        alert("All fields are required");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        // API validation
        if (!data.success) {
            alert("Invalid credentials or inactive account");
            return;
        }

        // Role mismatch protection
        if (data.role.toLowerCase() !== roleSelect.toLowerCase()) {
            alert("Selected role does not match your account role");
            return;
        }

        // Store user session info (simple frontend session)
        localStorage.setItem('userId', data.userId);
        localStorage.setItem('role', data.role);

        // Redirect by role
        switch (data.role) {
            case 'Admin':
                window.location.href = 'admin_dashboard.html';
                break;
            case 'Manager':
                window.location.href = 'manager_dashboard.html';
                break;
            case 'Cashier':
                window.location.href = 'cashier_dashboard.html';
                break;
            case 'Meter_Reader':
                window.location.href = 'meter_reader_dashboard.html';
                break;
            case 'Customer':
                window.location.href = 'customer_dashboard.html';
                break;
            default:
                alert("Invalid role");
        }

    } catch (err) {
        console.error(err);
        alert("Server error");
    }
}

















































/*// JS/login.js
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault(); // prevent default form submission
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const role = document.getElementById('role').value;

    if (!username || !password || !role) {
        alert("Please fill all fields and select your role.");
        return;
    }

    // Example: redirect based on role
    switch(role) {
        case 'manager':
            window.location.href = 'manager_dashboard.html';
            break;
        case 'cashier':
            window.location.href = 'cashier_dashboard.html';
            break;
        case 'meter_reader':
            window.location.href = 'meter_reader_dashboard.html';
            break;
        case 'admin':
            window.location.href = 'admin_dashboard.html';
            break;
        case 'Customer':
            window.location.href = 'customer_dashboard.html';
            break;
        default:
            alert("Invalid role selected!");
    }
});

//fetch calls

// Fetch all users (for admin)
async function fetchUsers() {
    const res = await fetch('http://localhost:3000/api/users');
    const users = await res.json();
    console.log(users);
}

// Add new user
async function addUser(user) {
    const res = await fetch('http://localhost:3000/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    });
    const data = await res.json();
    console.log(data);
}

// Example usage
// addUser({ Username: 'john', Password_Hash: 'hashedpass', Name: 'John Doe', Role: 'Customer', Status: 'Active' });

// ====== NEW: Fully integrated login with backend ======
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert("Please fill all fields.");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (data.success) {
            // Redirect based on role returned from backend
            switch(data.role) {
                case 'Admin': window.location.href = 'admin_dashboard.html'; break;
                case 'Manager': window.location.href = 'manager_dashboard.html'; break;
                case 'Cashier': window.location.href = 'cashier_dashboard.html'; break;
                case 'Meter_Reader': window.location.href = 'meter_reader_dashboard.html'; break;
                case 'Customer': window.location.href = 'customer_dashboard.html'; break;
                default: alert("Invalid role!");
            }
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}
*/