CREATE DATABASE DB_ums;
GO
USE DB_ums;


GO
----------------------------------------
-- 1. USERS
----------------------------------------
CREATE TABLE USERS (
    User_Num INT IDENTITY(1,1),

    -- Computed column must be PERSISTED for PK
    User_ID AS ('U' + RIGHT('0000' + CAST(User_Num AS VARCHAR(4)), 4)) PERSISTED NOT NULL
        CONSTRAINT PK_USERS PRIMARY KEY,

    Username VARCHAR(20) NOT NULL
        CONSTRAINT UQ_USERS_Username UNIQUE,

    Password_Hash VARCHAR(10) NOT NULL,
    Name VARCHAR(50) NOT NULL,

    Role VARCHAR(20) NOT NULL
        CONSTRAINT CHK_USERS_Role CHECK (Role IN ('Admin','Manager','Cashier','Meter_Reader','Customer')),

    Status VARCHAR(20) NOT NULL DEFAULT 'Active'
        CONSTRAINT CHK_USERS_Status CHECK (Status IN ('Active','Inactive','Suspended'))
);


GO
----------------------------------------
-- CUSTOMERS TABLE 
----------------------------------------
CREATE TABLE CUSTOMERS (
    Customer_Num INT IDENTITY(1,1),

    Customer_ID AS ('CUST' + RIGHT('0000' + CAST(Customer_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_CUSTOMERS PRIMARY KEY,

    User_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_CUSTOMERS_USERS REFERENCES USERS(User_ID),

    Name VARCHAR(50) NOT NULL,

    Email VARCHAR(30) NOT NULL
        CONSTRAINT UQ_CUSTOMERS_Email UNIQUE,

    Address_City VARCHAR(50),

    Customer_Type VARCHAR(20) NOT NULL
        CONSTRAINT CHK_CUSTOMERS_Type CHECK 
            (Customer_Type IN ('Household','Business','Government')),

    Outstanding_Balance DECIMAL(10,2) NOT NULL DEFAULT 0
);


GO
----------------------------------------
-- TARIFFS TABLE 
----------------------------------------
CREATE TABLE TARIFFS (
    Tariff_Num INT IDENTITY(1,1),

    Tariff_ID AS ('T' + RIGHT('0000' + CAST(Tariff_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_TARIFFS PRIMARY KEY,

    Utility_Type VARCHAR(20) NOT NULL,

    Unit_Rate DECIMAL(8,4) NOT NULL,

    Fixed_Charge DECIMAL(10,2) NOT NULL,

    Effective_Date DATE NOT NULL
);


GO
----------------------------------------
-- CONNECTIONS TABLE 
----------------------------------------
CREATE TABLE CONNECTIONS (
    Connection_Num INT IDENTITY(1,1),

    Connection_ID AS ('CON' + RIGHT('0000' + CAST(Connection_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_CONNECTIONS PRIMARY KEY,

    Customer_ID VARCHAR(8) NOT NULL
        CONSTRAINT FK_CONNECTIONS_CUSTOMERS REFERENCES CUSTOMERS(Customer_ID),

    Utility_Type VARCHAR(20) NOT NULL,

    Connection_Date DATE NOT NULL,

    Status VARCHAR(20) NOT NULL DEFAULT 'Active'
        CONSTRAINT CHK_CONNECTIONS_Status CHECK 
            (Status IN ('Active','Disconnected','Pending'))
);


GO
----------------------------------------
-- METERS TABLE
----------------------------------------
CREATE TABLE METERS (
    Meter_Num INT IDENTITY(1,1),

    Meter_ID AS ('M' + RIGHT('0000' + CAST(Meter_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_METERS PRIMARY KEY,

    Connection_ID VARCHAR(7) NOT NULL
        CONSTRAINT FK_METERS_CONNECTIONS REFERENCES CONNECTIONS(Connection_ID)
        CONSTRAINT UQ_METERS_Connection UNIQUE
);


GO
----------------------------------------
-- READINGS TABLE
----------------------------------------
CREATE TABLE READINGS (
    Reading_Num INT IDENTITY(1,1),

    Reading_ID AS ('R' + RIGHT('0000' + CAST(Reading_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_READINGS PRIMARY KEY,

    Meter_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_READINGS_METERS REFERENCES METERS(Meter_ID),

    Reading_Date DATE NOT NULL,

    Previous_Reading DECIMAL(10,2),

    Current_Reading DECIMAL(10,2) NOT NULL,

    Units_Consumed DECIMAL(10,2),

    Reading_Staff_ID VARCHAR(5)
        CONSTRAINT FK_READINGS_USERS REFERENCES USERS(User_ID),

    CONSTRAINT CHK_READINGS_Reading CHECK (Current_Reading >= Previous_Reading)
);


GO
----------------------------------------
-- BILLS TABLE
----------------------------------------
CREATE TABLE BILLS (
    Bill_Num INT IDENTITY(1,1),

    Bill_ID AS ('B' + RIGHT('0000' + CAST(Bill_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_BILLS PRIMARY KEY,

    Connection_ID VARCHAR(7) NOT NULL
        CONSTRAINT FK_BILLS_CONNECTIONS REFERENCES CONNECTIONS(Connection_ID),

    Tariff_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_BILLS_TARIFFS REFERENCES TARIFFS(Tariff_ID),

    Total_Amount DECIMAL(10,2) NOT NULL,
    Amount_Due DECIMAL(10,2) NOT NULL,

    Status VARCHAR(20) NOT NULL DEFAULT 'Unpaid'
        CONSTRAINT CHK_BILLS_Status CHECK (Status IN ('Unpaid','Paid','Overdue','Partial'))
);


GO
----------------------------------------
-- PAYMENTS TABLE 
----------------------------------------
CREATE TABLE PAYMENTS (
    Payment_Num INT IDENTITY(1,1),

    -- Computed & Persisted PK
    Payment_ID AS ('P' + RIGHT('0000' + CAST(Payment_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_PAYMENTS PRIMARY KEY,

    Bill_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_PAYMENTS_BILLS REFERENCES BILLS(Bill_ID),

    Amount_Paid DECIMAL(10,2) NOT NULL,

    Payment_Method VARCHAR(15),

    Cashier_ID VARCHAR(5)
        CONSTRAINT FK_PAYMENTS_USERS REFERENCES USERS(User_ID),

    Payment_Date DATE NOT NULL DEFAULT GETDATE()
);


GO
----------------------------------------
-- COMPLAINTS TABLE
----------------------------------------
CREATE TABLE COMPLAINTS (
    Complaint_Num INT IDENTITY(1,1),

    Complaint_ID AS ('COM' + RIGHT('0000' + CAST(Complaint_Num AS VARCHAR(4)), 4))
        PERSISTED NOT NULL
        CONSTRAINT PK_COMPLAINTS PRIMARY KEY,

    Customer_ID VARCHAR(8) NOT NULL
        CONSTRAINT FK_COMPLAINTS_CUSTOMERS REFERENCES CUSTOMERS(Customer_ID),

    Type VARCHAR(50),

    Status VARCHAR(20) NOT NULL DEFAULT 'Open'
        CONSTRAINT CHK_COMPLAINTS_Status CHECK (Status IN ('Open','In Progress','Closed')),

    Staff_Assigned VARCHAR(5)
        CONSTRAINT FK_COMPLAINTS_USERS REFERENCES USERS(User_ID)
);


GO
----------------------------------------
-- LOGIN TABLE
----------------------------------------

CREATE TABLE LOGIN_LOGS (
    Login_Num INT IDENTITY(1,1),
    Login_ID AS ('L' + RIGHT('0000' + CAST(Login_Num AS VARCHAR(4)),4)) PERSISTED PRIMARY KEY,
    User_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_LOGIN_USERS REFERENCES USERS(User_ID),
    Login_Time DATETIME DEFAULT GETDATE()
);


GO
----------------------------------------
-- LOGOUT TABLE
----------------------------------------

CREATE TABLE LOGOUT_LOGS (
    Logout_Num INT IDENTITY(1,1),
    Logout_ID AS ('O' + RIGHT('0000' + CAST(Logout_Num AS VARCHAR(4)),4)) PERSISTED PRIMARY KEY,
    User_ID VARCHAR(5) NOT NULL
        CONSTRAINT FK_LOGOUT_USERS REFERENCES USERS(User_ID),
    Logout_Time DATETIME DEFAULT GETDATE()
);