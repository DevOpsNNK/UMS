// routes/template.js

const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// Replace these with your table and column names
const TABLE_NAME = 'YourTable';
const ID_COLUMN = 'Id'; // primary key column

// Define your columns here with SQL type and required flag
const COLUMNS = [
    { name: 'col1', type: sql.VarChar(200), required: true },
    { name: 'col2', type: sql.Int, required: true },
    // add more columns as needed
];

// Helper to validate required fields
function validatePayload(payload) {
    const missing = COLUMNS.filter(c => c.required && (payload[c.name] === undefined || payload[c.name] === null));
    return missing.map(c => c.name);
}

// GET all
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`SELECT * FROM ${TABLE_NAME}`);
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET by ID
router.get(`/:id`, async (req, res) => {
    const id = req.params.id;
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), id) // adjust type if needed
            .query(`SELECT * FROM ${TABLE_NAME} WHERE ${ID_COLUMN} = @id`);

        if (!result.recordset[0]) {
            return res.status(404).json({ error: `${TABLE_NAME} not found` });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST create
router.post('/', async (req, res) => {
    const payload = req.body;

    // Validate required fields
    const missing = validatePayload(payload);
    if (missing.length > 0) {
        return res.status(400).json({ error: `Missing required fields: ${missing.join(', ')}` });
    }

    try {
        const pool = await getPool();
        const request = pool.request();

        // Add inputs
        COLUMNS.forEach(c => request.input(c.name, c.type, payload[c.name]));

        // Build query dynamically
        const columns = COLUMNS.map(c => c.name).join(', ');
        const values = COLUMNS.map(c => `@${c.name}`).join(', ');

        await request.query(`INSERT INTO ${TABLE_NAME} (${columns}) VALUES (${values})`);

        res.status(201).json({ message: `${TABLE_NAME} created successfully` });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update
router.put('/:id', async (req, res) => {
    const id = req.params.id;
    const payload = req.body;

    try {
        const pool = await getPool();

        // Check if record exists
        const check = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query(`SELECT ${ID_COLUMN} FROM ${TABLE_NAME} WHERE ${ID_COLUMN}=@id`);

        if (!check.recordset.length) {
            return res.status(404).json({ error: `${TABLE_NAME} not found` });
        }

        const request = pool.request();
        request.input('id', sql.VarChar(50), id);

        // Build SET dynamically
        const setClause = COLUMNS.map(c => {
            request.input(c.name, c.type, payload[c.name]);
            return `${c.name}=@${c.name}`;
        }).join(', ');

        await request.query(`UPDATE ${TABLE_NAME} SET ${setClause} WHERE ${ID_COLUMN}=@id`);

        res.json({ message: `${TABLE_NAME} updated successfully` });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE
router.delete('/:id', async (req, res) => {
    const id = req.params.id;
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.VarChar(50), id)
            .query(`DELETE FROM ${TABLE_NAME} WHERE ${ID_COLUMN}=@id`);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: `${TABLE_NAME} not found` });
        }

        res.json({ message: `${TABLE_NAME} deleted successfully` });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;

























































/*---- IGNORE ----


// routes/template.js
const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// GET all
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM YourTable'); // change
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// GET by id
router.get('/:id', async (req, res) => {
    const id = req.params.id;
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.Int, id)
            .query('SELECT * FROM YourTable WHERE Id = @id'); // change
        res.json(result.recordset[0] || null);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// POST create
router.post('/', async (req, res) => {
    const payload = req.body;
    try {
        const pool = await getPool();
        // Example insert — change columns and types
        await pool.request()
            .input('col1', sql.VarChar(200), payload.col1)
            .input('col2', sql.Int, payload.col2)
            .query('INSERT INTO YourTable (col1, col2) VALUES (@col1, @col2)');
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// PUT update
router.put('/:id', async (req, res) => {
    const id = req.params.id;
    const payload = req.body;
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', sql.Int, id)
            .input('col1', sql.VarChar(200), payload.col1)
            .query('UPDATE YourTable SET col1 = @col1 WHERE Id = @id');
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// DELETE
router.delete('/:id', async (req, res) => {
    const id = req.params.id;
    try {
        const pool = await getPool();
        await pool.request().input('id', sql.Int, id).query('DELETE FROM YourTable WHERE Id = @id');
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;


*//*---- END IGNORE ----*/
