// =======================================================
// admin_settings.js
// Handles Admin Settings frontend logic + backend API calls
// Aligned with USERS SQL + corrected HTML
// =======================================================

// Run code only after DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {

    // ===================================================
    // STAFF MANAGEMENT – CREATE USER
    // ===================================================

    // Get staff form inside Staff tab
    const staffForm = document.querySelector('#staff form');

    staffForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Stop page reload

        // ===============================
        // Get form values (HTML IDs)
        // ===============================
        const Name = document.getElementById('staffName').value.trim();
        const Username = document.getElementById('staffUsername').value.trim();
        const Role = document.getElementById('staffRole').value;
        const Status = document.getElementById('staffStatus').value || 'Active';

        // Frontend validation
        if (!Name || !Username || !Role) {
            alert('All required fields must be filled!');
            return;
        }

        try {
            // ===============================
            // Send data to backend
            // ===============================
            const response = await fetch('http://localhost:3000/api/users', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    Username: Username,          // SQL: Username
                    Password_Hash: '12345',      // Temporary (student project)
                    Name: Name,                  // SQL: Name
                    Role: Role,                  // SQL CHECK constraint
                    Status: Status               // SQL default = Active
                })
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.error || 'Failed to add user');
                return;
            }

            // ===============================
            // Add row to table AFTER DB success
            // ===============================
            const tbody = document.querySelector('#staff tbody');
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${data.User_ID || 'U????'}</td>
                <td>${Username}</td>
                <td>${Name}</td>
                <td>${Role}</td>
                <td>${Status}</td>
                <td>
                    <a href="#" class="reset">Reset Password</a> |
                    <a href="#" class="deactivate">Deactivate</a>
                </td>
            `;

            tbody.appendChild(row);

            staffForm.reset();
            alert('User added successfully!');

        } catch (error) {
            console.error(error);
            alert('Server connection error');
        }
    });

    // ===================================================
    // STAFF TABLE ACTIONS (Deactivate / Reset)
    // ===================================================

    document.querySelector('#staff tbody').addEventListener('click', async (e) => {

        const row = e.target.closest('tr');
        if (!row) return;

        const userId = row.children[0].textContent; // SQL: User_ID

        // ===============================
        // Deactivate user
        // ===============================
        if (e.target.classList.contains('deactivate')) {
            e.preventDefault();

            if (!confirm('Deactivate this user?')) return;

            try {
                const response = await fetch(`http://localhost:3000/api/users/${userId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        Status: 'Inactive'
                    })
                });

                const data = await response.json();

                if (!response.ok) {
                    alert(data.error || 'Failed to deactivate user');
                    return;
                }

                // Update UI
                row.children[4].textContent = 'Inactive';
                alert('User deactivated');

            } catch (err) {
                console.error(err);
                alert('Server error');
            }
        }

        // ===============================
        // Reset password (UI demo)
        // ===============================
        if (e.target.classList.contains('reset')) {
            e.preventDefault();
            alert('Password reset feature coming soon!');
        }
    });

    // ===================================================
    // TARIFF FORM (UI ONLY – BACKEND NOT CONNECTED)
    // ===================================================

    const tariffForm = document.querySelector('#tariff form');

    tariffForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const utility = document.getElementById('utilityType').value;
        const rate = document.getElementById('rate').value;
        const fixed = document.getElementById('fixedCharge').value || '0';
        const date = document.getElementById('effectiveDate').value;

        if (!utility || !rate || !date) {
            alert('Please fill all tariff fields');
            return;
        }

        const tbody = document.querySelector('#tariff tbody');
        const id = `TRF-${Math.floor(Math.random() * 900 + 100)}`;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${id}</td>
            <td>${utility}</td>
            <td>${parseFloat(rate).toFixed(3)}</td>
            <td>${parseFloat(fixed).toFixed(2)}</td>
            <td>${date}</td>
            <td>Active</td>
        `;

        tbody.appendChild(row);
        tariffForm.reset();
    });

    // ===================================================
    // SYSTEM UTILITIES BUTTONS (DEMO ONLY)
    // ===================================================

    document.querySelectorAll('.maintenance-item button').forEach(btn => {
        btn.addEventListener('click', () => {
            alert(`${btn.textContent} executed (demo only)`);
        });
    });
});


// ===================================================
// LOGIN WITH BACKEND (ALREADY CORRECT)
// ===================================================

async function loginWithBackend() {

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert('Please fill all fields.');
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (!res.ok) {
            alert(data.error || 'Login failed');
            return;
        }

        // Redirect user based on role
        const dashboards = {
            Admin: 'admin_dashboard.html',
            Manager: 'manager_dashboard.html',
            Cashier: 'cashier_dashboard.html',
            Meter_Reader: 'meter_reader_dashboard.html',
            Customer: 'customer_dashboard.html'
        };

        window.location.href = dashboards[data.role] || '#';

    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}


























/*// admin_settings.js

document.addEventListener('DOMContentLoaded', () => {
    // Staff form
    const staffForm = document.querySelector('#staff form');
    staffForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = document.getElementById('staffName').value.trim();
        const role = document.getElementById('staffRole').value;
        const staffID = document.getElementById('staffID').value.trim();

        if(name && role && staffID) {
            const tbody = document.querySelector('#staff tbody');
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${staffID}</td>
                <td>${name}</td>
                <td>${role}</td>
                <td>Active</td>
                <td>
                    <a href="#" class="reset">Reset Password</a> | 
                    <a href="#" class="deactivate">Deactivate</a>
                </td>
            `;
            tbody.appendChild(row);

            staffForm.reset();
        }
    });

    // Staff table actions (Reset / Deactivate)
    document.querySelector('#staff tbody').addEventListener('click', function(e) {
        if(e.target.classList.contains('reset')) {
            e.preventDefault();
            alert('Password reset successfully!');
        }
        if(e.target.classList.contains('deactivate')) {
            e.preventDefault();
            const row = e.target.closest('tr');
            row.querySelector('td:nth-child(4)').textContent = 'Inactive';
            alert('Staff deactivated!');
        }
    });

    // Tariff form
    const tariffForm = document.querySelector('#tariff form');
    tariffForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const utility = document.getElementById('utilityType').value;
        const rate = document.getElementById('rate').value;
        const fixed = document.getElementById('fixedCharge').value || '0';
        const date = document.getElementById('effectiveDate').value;

        const tbody = document.querySelector('#tariff tbody');
        const id = `TRF-${Math.floor(Math.random() * 900 + 100)}`; // random ID

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${id}</td>
            <td>${utility}</td>
            <td>$${parseFloat(rate).toFixed(3)}</td>
            <td>$${parseFloat(fixed).toFixed(2)}</td>
            <td>${date}</td>
            <td>Active</td>
        `;
        tbody.appendChild(row);

        tariffForm.reset();
    });

    // Utility buttons
    document.querySelectorAll('.maintenance-item button').forEach(btn => {
        btn.addEventListener('click', () => {
            alert(`${btn.textContent} executed!`);
        });
    });
});

// ====== NEW: Fully integrated login with backend ======
async function loginWithBackend() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert("Please fill all fields.");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (data.success) {
            // Redirect based on role returned from backend
            switch (data.role) {
                case 'Admin':
                    window.location.href = 'admin_dashboard.html';
                    break;
                case 'Manager':
                    window.location.href = 'manager_dashboard.html';
                    break;
                case 'Cashier':
                    window.location.href = 'cashier_dashboard.html';
                    break;
                case 'Meter_Reader':
                    window.location.href = 'meter_reader_dashboard.html';
                    break;
                case 'Customer':
                    window.location.href = 'customer_dashboard.html';
                    break;
                default:
                    alert("Invalid role returned from server!");
            }
        } else {
            alert('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
}
*/
