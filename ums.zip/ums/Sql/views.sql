---------------------------------------------
-- views.sql- sql for Views in Utility Management System
------------------------------------------------------------

USE DB_ums;
GO

------------------------------------------------------------
-- VIEW 1: Unpaid bills summary
------------------------------------------------------------
CREATE OR ALTER VIEW vw_UnpaidBillsSummary
AS
SELECT
    b.Bill_ID,
    cn.Connection_ID,
    cn.Customer_ID,
    c.Name AS CustomerName,
    c.Email,
    b.Total_Amount,
    b.Amount_Due,
    b.Status
FROM BILLS b
INNER JOIN CONNECTIONS cn ON b.Connection_ID = cn.Connection_ID
INNER JOIN CUSTOMERS c ON cn.Customer_ID = c.Customer_ID
WHERE b.Amount_Due > 0;
GO


------------------------------------------------------------
-- VIEW 2: Monthly revenue report
------------------------------------------------------------
CREATE OR ALTER VIEW vw_MonthlyRevenue
AS
SELECT
    YEAR(p.Payment_Date) AS [Year],
    MONTH(p.Payment_Date) AS [Month],
    CONCAT(
        YEAR(p.Payment_Date), '-', 
        RIGHT('0' + CAST(MONTH(p.Payment_Date) AS VARCHAR(2)), 2)
    ) AS YearMonth,
    COUNT(*) AS PaymentsCount,
    SUM(p.Amount_Paid) AS TotalPaid
FROM PAYMENTS p
GROUP BY 
    YEAR(p.Payment_Date),
    MONTH(p.Payment_Date),
    CONCAT(
        YEAR(p.Payment_Date), '-', 
        RIGHT('0' + CAST(MONTH(p.Payment_Date) AS VARCHAR(2)), 2)
    );
GO
