--------------------------------------------------
--triggers.sql- sql for Triggers for Utility Management System
---------------------------------------------------


USE DB_ums;
GO

--Trigger 1: TRG_Payments_AfterInsert

CREATE OR ALTER TRIGGER TRG_Payments_AfterInsert
ON PAYMENTS
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Update the Bill Amount Due & Status
    UPDATE b
    SET 
        b.Amount_Due = CASE 
                        WHEN b.Amount_Due - i.Amount_Paid < 0 THEN 0 
                        ELSE b.Amount_Due - i.Amount_Paid 
                       END,
        b.Status = CASE 
                    WHEN b.Amount_Due - i.Amount_Paid <= 0 THEN 'Paid'
                    WHEN b.Amount_Due - i.Amount_Paid < b.Total_Amount THEN 'Partial'
                    ELSE b.Status
                   END
    FROM BILLS b
    INNER JOIN INSERTED i ON b.Bill_ID = i.Bill_ID;

    -- 2. Recalculate Outstanding Balance
    UPDATE c
    SET Outstanding_Balance = COALESCE(
        (SELECT SUM(b2.Amount_Due)
         FROM BILLS b2
         INNER JOIN CONNECTIONS cn2 ON b2.Connection_ID = cn2.Connection_ID
         WHERE cn2.Customer_ID = c.Customer_ID
        ), 0)
    FROM CUSTOMERS c
    WHERE c.Customer_ID IN (
        SELECT cn.Customer_ID
        FROM INSERTED i
        INNER JOIN BILLS b3 ON i.Bill_ID = b3.Bill_ID
        INNER JOIN CONNECTIONS cn ON b3.Connection_ID = cn.Connection_ID
    );

    -- 3. Auto-create Customer user if not exists
    INSERT INTO USERS (Username, Password_Hash, Name, Role, Status)
    SELECT DISTINCT c.Email, 'default_hash', c.Name, 'Customer', 'Active'
    FROM INSERTED i
    INNER JOIN BILLS b4 ON i.Bill_ID = b4.Bill_ID
    INNER JOIN CONNECTIONS cn4 ON b4.Connection_ID = cn4.Connection_ID
    INNER JOIN CUSTOMERS c ON cn4.Customer_ID = c.Customer_ID
    WHERE c.Email IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM USERS u WHERE u.Username = c.Email);
END;
GO

--Trigger 2: TRG_Readings_AfterInsert

CREATE OR ALTER TRIGGER TRG_Readings_AfterInsert
ON READINGS
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ToUpdate AS (
        SELECT 
            r.Reading_ID,
            r.Meter_ID,
            r.Current_Reading,
            LAG(r.Current_Reading) OVER (
                 PARTITION BY r.Meter_ID 
                 ORDER BY r.Reading_Date, r.Reading_ID
            ) AS PrevVal
        FROM READINGS r
        INNER JOIN INSERTED i ON r.Reading_ID = i.Reading_ID
    )
    UPDATE r
    SET 
        Previous_Reading = COALESCE(t.PrevVal, 0),
        Units_Consumed = r.Current_Reading - COALESCE(t.PrevVal, 0)
    FROM READINGS r
    INNER JOIN ToUpdate t ON r.Reading_ID = t.Reading_ID;
END;
GO
