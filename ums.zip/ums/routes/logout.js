// routes/logout.js

const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// POST /api/logout
router.post('/', async (req, res) => {
    const { userId } = req.body;

    try {
        const pool = await getPool();

        await pool.request()
            .input('User_ID', sql.VarChar(5), userId)
            .query(`INSERT INTO LOGOUT_LOGS (User_ID) VALUES (@User_ID)`);

        res.json({ success: true });

    } catch (err) {
        res.status(500).json({ success: false });
    }
});

module.exports = router;

















































/*const express = require('express');
const router = express.Router();
const { getPool, sql } = require('../db');

// POST /api/logout
router.post('/', async (req, res) => {
    const { userId } = req.body;

    try {
        const pool = await getPool();

        if (userId) {
            await pool.request()
                .input('userId', sql.Int, userId)
                .query(`
                    INSERT INTO LogoutLogs (UserID, LogoutTime)
                    VALUES (@userId, GETDATE())
                `);
        }

        res.json({ success: true });

    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false });
    }
});

module.exports = router;
*/