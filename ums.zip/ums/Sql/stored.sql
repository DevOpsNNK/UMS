-------------------------------------------------
-- stored.sql - Stored Procedures for Utility Management System
-------------------------------------------------


USE DB_ums;
GO

-- STORED PROCEDURE 1: Generate Bill for a Customer
IF OBJECT_ID('sp_GenerateBillForCustomer', 'P') IS NOT NULL
    DROP PROCEDURE sp_GenerateBillForCustomer;
GO

CREATE PROCEDURE sp_GenerateBillForCustomer
    @CustomerID VARCHAR(50),
    @Year INT,
    @Month INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Billing period
    DECLARE @MonthStart DATE = DATEFROMPARTS(@Year, @Month, 1);
    DECLARE @MonthEnd   DATE = EOMONTH(@MonthStart);

    -- Get customer connections
    ;WITH CustomerConnections AS (
        SELECT Connection_ID, Utility_Type
        FROM CONNECTIONS
        WHERE Customer_ID = @CustomerID
    ),
    -- Calculate units consumed per connection
    UnitsPerConn AS (
        SELECT 
            cc.Connection_ID,
            cc.Utility_Type,
            ISNULL(SUM(
                CASE 
                    WHEN r.Units_Consumed IS NOT NULL 
                        THEN r.Units_Consumed
                    ELSE (r.Current_Reading - COALESCE(r.Previous_Reading, 0))
                END
            ), 0) AS Units
        FROM CustomerConnections cc
        LEFT JOIN METERS m 
            ON m.Connection_ID = cc.Connection_ID
        LEFT JOIN READINGS r 
            ON r.Meter_ID = m.Meter_ID
           AND r.Reading_Date BETWEEN @MonthStart AND @MonthEnd
        GROUP BY cc.Connection_ID, cc.Utility_Type
    )

    -- Insert bills (DO NOT include Bill_ID)
    INSERT INTO BILLS
        (Connection_ID, Tariff_ID, Total_Amount, Amount_Due, Status)
    SELECT
        u.Connection_ID,
        t.Tariff_ID,
        ROUND(u.Units * t.Unit_Rate + t.Fixed_Charge, 2),
        ROUND(u.Units * t.Unit_Rate + t.Fixed_Charge, 2),
        'Unpaid'
    FROM UnitsPerConn u
    CROSS APPLY (
        SELECT TOP (1)
            tf.Tariff_ID,
            tf.Unit_Rate,
            tf.Fixed_Charge
        FROM TARIFFS tf
        WHERE tf.Utility_Type = u.Utility_Type
          AND tf.Effective_Date <= @MonthEnd
        ORDER BY tf.Effective_Date DESC
    ) t;

    -- Update customer's outstanding balance
    UPDATE c
    SET Outstanding_Balance = ISNULL((
        SELECT SUM(b.Amount_Due)
        FROM BILLS b
        INNER JOIN CONNECTIONS cn 
            ON b.Connection_ID = cn.Connection_ID
        WHERE cn.Customer_ID = c.Customer_ID
    ), 0)
    FROM CUSTOMERS c
    WHERE c.Customer_ID = @CustomerID;
END;
GO


-- STORED PROCEDURE 2: List Defaulters
IF OBJECT_ID('sp_ListDefaulters', 'P') IS NOT NULL
    DROP PROCEDURE sp_ListDefaulters;
GO

CREATE PROCEDURE sp_ListDefaulters
    @Threshold DECIMAL(12,2) = 1000.00
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Customer_ID,
        Name,
        Email,
        Address_City,
        Outstanding_Balance
    FROM CUSTOMERS
    WHERE Outstanding_Balance > @Threshold
    ORDER BY Outstanding_Balance DESC;
END;
GO
