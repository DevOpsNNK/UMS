// routes/tariffs.js
const express = require('express');
const router = express.Router();
const sql = require('mssql');
const { getPool } = require('../db');

// GET all tariffs
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM TARIFFS');
        res.json(result.recordset);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// GET tariff by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getPool();

        // ❌ Was sql.VarChar(50), fixed to sql.Int to match DB INT
        const result = await pool.request()
            .input('id', sql.Int, id)
            .query('SELECT * FROM TARIFFS WHERE Tariff_ID=@id');

        if (!result.recordset[0]) {
            return res.status(404).json({ error: 'Tariff not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// POST new tariff
router.post('/', async (req, res) => {
    try {
        const { Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date } = req.body;

        if (!Utility_Type || Unit_Rate === undefined || Fixed_Charge === undefined || !Effective_Date) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();
        await pool.request()
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            // ❌ Was DECIMAL(10,2), fixed to match DB DECIMAL(8,4)
            .input('Unit_Rate', sql.Decimal(8, 4), parseFloat(Unit_Rate))
            .input('Fixed_Charge', sql.Decimal(10, 2), parseFloat(Fixed_Charge))
            .input('Effective_Date', sql.Date, new Date(Effective_Date))
            .query(`INSERT INTO TARIFFS (Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date)
                    VALUES (@Utility_Type, @Unit_Rate, @Fixed_Charge, @Effective_Date)`);

        res.status(201).json({ message: 'Tariff added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// PUT update tariff
router.put('/:id', async (req, res) => {
    try {
        const { Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date } = req.body;

        if (!Utility_Type || Unit_Rate === undefined || Fixed_Charge === undefined || !Effective_Date) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        const pool = await getPool();

        // ❌ Was sql.VarChar(50), fixed to sql.Int
        const check = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('SELECT Tariff_ID FROM TARIFFS WHERE Tariff_ID=@id');

        if (check.recordset.length === 0) {
            return res.status(404).json({ error: 'Tariff not found' });
        }

        await pool.request()
            .input('id', sql.Int, req.params.id)
            .input('Utility_Type', sql.VarChar(50), Utility_Type)
            .input('Unit_Rate', sql.Decimal(8, 4), parseFloat(Unit_Rate))
            .input('Fixed_Charge', sql.Decimal(10, 2), parseFloat(Fixed_Charge))
            .input('Effective_Date', sql.Date, new Date(Effective_Date))
            .query(`UPDATE TARIFFS
                    SET Utility_Type=@Utility_Type, Unit_Rate=@Unit_Rate, Fixed_Charge=@Fixed_Charge, Effective_Date=@Effective_Date
                    WHERE Tariff_ID=@id`);

        res.json({ message: 'Tariff updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// DELETE tariff
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();

        // ❌ Was sql.VarChar(50), fixed to sql.Int
        const result = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('DELETE FROM TARIFFS WHERE Tariff_ID=@id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Tariff not found' });
        }

        res.json({ message: 'Tariff deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;















































































/*---- IGNORE ----


// routes/customers.js
const express = require('express');
const router = express.Router();
const { getPool } = require('../db');

// GET all tariffs
router.get('/', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query('SELECT * FROM TARIFFS');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// GET tariff by ID
router.get('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', req.params.id)
            .query('SELECT * FROM TARIFFS WHERE Tariff_ID=@id');
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// POST new tariff
router.post('/', async (req, res) => {
    try {
        const { Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('Utility_Type', Utility_Type)
            .input('Unit_Rate', Unit_Rate)
            .input('Fixed_Charge', Fixed_Charge)
            .input('Effective_Date', Effective_Date)
            .query(`INSERT INTO TARIFFS (Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date)
                    VALUES (@Utility_Type, @Unit_Rate, @Fixed_Charge, @Effective_Date)`);
        res.json({ message: 'Tariff added successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// PUT update tariff
router.put('/:id', async (req, res) => {
    try {
        const { Utility_Type, Unit_Rate, Fixed_Charge, Effective_Date } = req.body;
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .input('Utility_Type', Utility_Type)
            .input('Unit_Rate', Unit_Rate)
            .input('Fixed_Charge', Fixed_Charge)
            .input('Effective_Date', Effective_Date)
            .query(`UPDATE TARIFFS
                    SET Utility_Type=@Utility_Type, Unit_Rate=@Unit_Rate, Fixed_Charge=@Fixed_Charge, Effective_Date=@Effective_Date
                    WHERE Tariff_ID=@id`);
        res.json({ message: 'Tariff updated successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// DELETE tariff
router.delete('/:id', async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request()
            .input('id', req.params.id)
            .query('DELETE FROM TARIFFS WHERE Tariff_ID=@id');
        res.json({ message: 'Tariff deleted successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;

*//*---- END IGNORE ----*/
